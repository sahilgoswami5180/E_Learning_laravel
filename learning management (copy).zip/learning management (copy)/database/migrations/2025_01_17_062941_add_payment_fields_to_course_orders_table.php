<?php
// database/migrations/xxxx_xx_xx_xxxxxx_add_payment_fields_to_course_orders_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPaymentFieldsToCourseOrdersTable extends Migration
{
    public function up()
    {
        Schema::table('course_orders', function (Blueprint $table) {
            $table->string('course_name')->nullable(); // Optionally store the course name here
        });
    }

    public function down()
    {
        Schema::table('course_orders', function (Blueprint $table) {
            $table->dropColumn(['course_name']);
        });
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Create the users table
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable(); // Email verification timestamp
            $table->string('mobile_number')->unique(); // Store mobile number
            $table->string('password');
            $table->string('role')->default('user'); // Default role is 'user'
            $table->string('email_verification_token')->nullable()->unique(); // Email verification token column
            $table->string('otp')->nullable(); // OTP column to store the phone verification OTP
            $table->timestamp('otp_verified_at')->nullable(); // Timestamp for phone OTP verification
            $table->rememberToken();
            $table->timestamps();
        });

        // Create the password reset tokens table (Laravel 8+ convention)
        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->index();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        // Create the sessions table (optional; check if needed)
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete(); // Foreign key to users table, nullable
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens'); // Laravel 8+ table
        Schema::dropIfExists('sessions');
    }
};

<?php

namespace App\Http\Controllers;

use App\Models\Quiz;
use App\Models\Course;
use App\Models\Lesson;
use Illuminate\Http\Request;

class QuizController extends Controller
{
    public function index(Request $request)
    {
        // Fetch filter values from the request
        $course_id = $request->input('course_id');
        $lesson_id = $request->input('lesson_id');
        $title = $request->input('title');
        $status = $request->input('status'); // 'active' or 'trashed'

        // Paginate quizzes with filters applied
        $quizzes = Quiz::with(['course', 'lesson'])
            ->when($course_id, function ($query) use ($course_id) {
                return $query->where('course_id', $course_id);
            })
            ->when($lesson_id, function ($query) use ($lesson_id) {
                return $query->where('lesson_id', $lesson_id);
            })
            ->when($title, function ($query) use ($title) {
                return $query->where('title', 'like', "%{$title}%");
            })
            ->when($status, function ($query) use ($status) {
                if ($status === 'trashed') {
                    return $query->onlyTrashed(); // Fetch trashed quizzes
                } elseif ($status === 'active') {
                    return $query->whereNull('deleted_at'); // Fetch only active quizzes
                }
            })
            ->paginate(10); // You can adjust the number per page as needed

        // Pass the filters to the view
        $courses = Course::all();
        $lessons = Lesson::all();
        return view('quizzes.index', compact('quizzes', 'courses', 'lessons', 'course_id', 'lesson_id', 'title', 'status'));
    }

    public function create()
    {
        $courses = Course::all();
        $lessons = Lesson::all();
        return view('quizzes.create', compact('courses', 'lessons'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'course_id' => 'nullable|exists:courses,id',
            'lesson_id' => 'nullable|exists:lessons,id',
            'title' => 'required|string|max:255',
        ]);

        Quiz::create($request->all());
        return redirect()->route('quizzes.index')->with('success', 'Quiz created successfully!');
    }

    public function show($id)
    {
        $quiz = Quiz::with(['course', 'lesson'])->findOrFail($id);
        return view('quizzes.show', compact('quiz'));
    }

    public function edit($id)
    {
        $quiz = Quiz::findOrFail($id);
        $courses = Course::all();
        $lessons = Lesson::all();
        return view('quizzes.edit', compact('quiz', 'courses', 'lessons'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'course_id' => 'nullable|exists:courses,id',
            'lesson_id' => 'nullable|exists:lessons,id',
            'title' => 'required|string|max:255',
        ]);

        $quiz = Quiz::findOrFail($id);
        $quiz->update($request->all());
        return redirect()->route('quizzes.index')->with('success', 'Quiz updated successfully!');
    }

    // Soft Delete Method
    public function destroy($id)
    {
        $quiz = Quiz::findOrFail($id);
        $quiz->delete(); // Soft delete the quiz
        return redirect()->route('quizzes.index')->with('success', 'Quiz deleted successfully!');
    }

    // Restore Soft Deleted Quiz
    public function restore($id)
    {
        $quiz = Quiz::onlyTrashed()->findOrFail($id);
        $quiz->restore(); // Restore the quiz
        return redirect()->route('quizzes.index')->with('success', 'Quiz restored successfully!');
    }

    // Permanently Delete Soft Deleted Quiz
    public function forceDelete($id)
    {
        $quiz = Quiz::onlyTrashed()->findOrFail($id);
        $quiz->forceDelete(); // Permanently delete the quiz
        return redirect()->route('quizzes.index')->with('success', 'Quiz permanently deleted!');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\User;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function index(Request $request)
    {
        // Start a query on the Course model
        $query = Course::with('instructor')->withTrashed();

        // Apply filters based on the request parameters
        if ($request->has('title') && $request->title != '') {
            $query->where('title', 'like', '%' . $request->title . '%');
        }

        if ($request->has('instructor') && $request->instructor != '') {
            $query->whereHas('instructor', function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->instructor . '%');
            });
        }

        if ($request->has('duration') && $request->duration != '') {
            $query->where('duration', $request->duration);
        }

        // Paginate results (10 per page, but this can be adjusted)
        $courses = $query->paginate(10)->appends($request->query());

        // Return view with filtered and paginated courses
        return view('course.index', compact('courses'));
    }

    public function create()
    {
        // Fetch users with the 'instructor' role
        $instructors = User::where('role', 'instructor')->get();
        return view('course.create', compact('instructors'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'duration' => 'required|integer|min:1', // Validate positive duration
            'price' => 'required|numeric|min:0', // Validate non-negative price
            'instructor_id' => 'nullable|exists:users,id', // Ensure instructor exists
        ]);

        // Create a new course
        Course::create($request->all());
        return redirect()->route('course.index')->with('success', 'Course created successfully!');
    }

    public function edit(Course $course)
    {
        // Fetch instructors for the dropdown
        $instructors = User::where('role', 'instructor')->get();
        return view('course.edit', compact('course', 'instructors'));
    }

    public function update(Request $request, Course $course)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'duration' => 'required|integer|min:1', // Validate positive duration
            'price' => 'required|numeric|min:0', // Validate non-negative price
            'instructor_id' => 'nullable|exists:users,id', // Ensure instructor exists
        ]);

        // Update the course details
        $course->update($request->all());
        return redirect()->route('course.index')->with('success', 'Course updated successfully!');
    }

    public function destroy(Course $course)
    {
        // Soft delete the course
        $course->delete();
        return redirect()->route('course.index')->with('success', 'Course deleted successfully!');
    }

    public function restore($id)
    {
        // Restore a soft-deleted course
        $course = Course::withTrashed()->findOrFail($id);
        $course->restore();

        return redirect()->route('course.index')->with('success', 'Course restored successfully!');
    }

    public function forceDelete($id)
    {
        // Permanently delete a soft-deleted course
        $course = Course::withTrashed()->findOrFail($id);
        $course->forceDelete();

        return redirect()->route('course.index')->with('success', 'Course permanently deleted!');
    }
}

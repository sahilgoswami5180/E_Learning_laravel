<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\CourseOrder;
use Illuminate\Http\Request;
use Razorpay\Api\Api;
use Auth;

class RazorpayController extends Controller
{
    /**
     * Show the checkout page for the course.
     */
    public function checkout(Request $request, $courseId)
    {
        // Ensure user is logged in and has 'user' role
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login')->with('error', 'Please log in to purchase this course.');
        }

        // Retrieve the course
        $course = Course::findOrFail($courseId);
        $finalTotal = $course->price; // Get the course price

        // Create Razorpay order
        $razorpayOrder = $this->createRazorpayOrder($finalTotal);

        // Save the order details in the database
        $courseOrder = CourseOrder::create([
            'user_id' => Auth::id(),
            'total' => $finalTotal,
            'status' => 'pending',
            'course_id' => $course->id, // Associate course ID with the order
            'razorpay_order_id' => $razorpayOrder['id'],
            'payment_status' => 'pending',
        ]);

        // Return the checkout view with the Razorpay order
        return view('student.razorpay_checkout', compact('razorpayOrder', 'course', 'finalTotal'))
               ->with('success', 'You are about to make a payment. Please proceed with the checkout.');
    }

    /**
     * Handle successful payment.
     */
    public function paymentSuccess(Request $request)
    {
        // Ensure user is logged in and has 'user' role
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login')->with('error', 'Please log in to complete the payment.');
        }

        // Get Razorpay payment details from the request
        $razorpayOrderId = $request->input('razorpay_order_id');
        $razorpayPaymentId = $request->input('razorpay_payment_id');
        $razorpaySignature = $request->input('razorpay_signature');

        // Find the course order associated with this Razorpay order ID
        $courseOrder = CourseOrder::where('razorpay_order_id', $razorpayOrderId)->first();
        if (!$courseOrder) {
            return redirect()->route('student.index')->with('error', 'Order not found.');
        }

        // Find the associated course
        $course = Course::findOrFail($courseOrder->course_id);

        // Check if the payment already exists
        if ($courseOrder->razorpay_payment_id) {
            return redirect()->route('student.index')->with('error', 'Payment has already been processed.');
        }

        // Optionally verify the payment signature here if necessary

        // Update the course order with payment details
        $courseOrder->update([
            'razorpay_payment_id' => $razorpayPaymentId,
            'razorpay_signature' => $razorpaySignature,
            'status' => 'completed',
            'payment_status' => 'success',
            'course_name' => $course->title,  // Make sure the course name is correctly referenced here
        ]);

        // Return success response
        return redirect()->route('student.index')
            ->with('success', 'Payment successful! You now have access to the course.');
    }

    /**
     * Handle payment cancellation.
     */
    public function paymentCancel(Request $request)
    {
        $razorpayOrderId = $request->input('razorpay_order_id');

        // Find the course order associated with this Razorpay order ID
        $courseOrder = CourseOrder::where('razorpay_order_id', $razorpayOrderId)->first();

        if ($courseOrder) {
            // Update the order status to cancelled
            $courseOrder->update([
                'status' => 'cancelled',
                'payment_status' => 'failed', // You can also mark it as failed
            ]);
        }

        return redirect()->route('student.index')->with('error', 'Payment was cancelled. Please try again.');
    }

    /**
     * Create a Razorpay Order.
     */
    private function createRazorpayOrder($amount)
    {
        $api = new Api(env('RAZORPAY_KEY'), env('RAZORPAY_SECRET'));
        $orderData = [
            'receipt'         => 'order_' . rand(1000, 9999),
            'amount'          => (int) ($amount * 100), // Amount in paise
            'currency'        => 'INR',
            'payment_capture' => 1, // Auto-capture payment
        ];

        return $api->order->create($orderData);
    }
}

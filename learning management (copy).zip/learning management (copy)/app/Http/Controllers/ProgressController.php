<?php

namespace App\Http\Controllers;

use App\Models\Progress;
use App\Models\Course;
use Illuminate\Http\Request;

class ProgressController extends Controller
{
    public function show($userId)
    {
        $progress = Progress::where('user_id', $userId)->with('course')->get();
        return view('progress.show', compact('progress'));
    }

    public function update(Request $request, $userId)
    {
        $request->validate([
            'course_id' => 'required|exists:courses,id',
            'completed_lessons' => 'nullable|array',
            'completed_quizzes' => 'nullable|array',
            'completion_percentage' => 'required|integer|min:0|max:100',
        ]);

        $progress = Progress::firstOrNew(['user_id' => $userId, 'course_id' => $request->course_id]);
        $progress->update([
            'completed_lessons' => $request->completed_lessons,
            'completed_quizzes' => $request->completed_quizzes,
            'completion_percentage' => $request->completion_percentage,
        ]);

        return redirect()->back()->with('success', 'Progress updated successfully!');
    }
}

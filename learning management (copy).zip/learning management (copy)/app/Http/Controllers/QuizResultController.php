<?php

namespace App\Http\Controllers;

use App\Models\QuizResult;
use App\Models\Quiz;
use App\Models\User;
use Illuminate\Http\Request;

class QuizResultController extends Controller
{
    /**
     * Display a listing of quiz results with optional filters.
     */
    public function index(Request $request)
    {
        $results = QuizResult::with(['quiz', 'user']) // Eager load the quiz and user relations
            // Apply quiz filter if 'quiz_id' query parameter is provided
            ->when($request->quiz_id, function ($query) use ($request) {
                $query->where('quiz_id', $request->quiz_id);
            })
            // Apply user filter if 'user_id' query parameter is provided
            ->when($request->user_id, function ($query) use ($request) {
                $query->where('user_id', $request->user_id);
            })
            // Apply score filter if 'score' query parameter is provided
            ->when($request->score, function ($query) use ($request) {
                $query->where('score', $request->score);
            })
            // Paginate the results with 10 results per page
            ->paginate(10);

        // Fetch all quizzes and users for filtering purposes
        $quizzes = Quiz::all();
        $users = User::all();

        // Pass the filtered results, quizzes, and users to the view
        return view('quiz_results.index', compact('results', 'quizzes', 'users'));
    }

    /**
     * Show the form for creating a new quiz result.
     */
    public function create()
    {
        $quizzes = Quiz::all();
        $users = User::all();
        return view('quiz_results.create', compact('quizzes', 'users'));
    }

    /**
     * Store a newly created quiz result in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'quiz_id' => 'required|exists:quizzes,id',
            'user_id' => 'required|exists:users,id',
            'score' => 'required|integer|min:0|max:100',
            'completed' => 'required|boolean',
        ]);

        QuizResult::create($request->all());

        return redirect()->route('quiz_results.index')
            ->with('success', 'Quiz result added successfully!');
    }

    /**
     * Display the specified quiz result.
     */
    public function show(QuizResult $quizResult)
    {
        return view('quiz_results.show', compact('quizResult'));
    }

    /**
     * Show the form for editing the specified quiz result.
     */
    public function edit(QuizResult $quizResult)
    {
        $quizzes = Quiz::all();
        $users = User::all();
        return view('quiz_results.edit', compact('quizResult', 'quizzes', 'users'));
    }

    /**
     * Update the specified quiz result in storage.
     */
    public function update(Request $request, QuizResult $quizResult)
    {
        $request->validate([
            'quiz_id' => 'required|exists:quizzes,id',
            'user_id' => 'required|exists:users,id',
            'score' => 'required|integer|min:0|max:100',
            'completed' => 'required|boolean',
        ]);

        $quizResult->update($request->all());

        return redirect()->route('quiz_results.index')
            ->with('success', 'Quiz result updated successfully!');
    }

    /**
     * Remove the specified quiz result from storage.
     */
    public function destroy(QuizResult $quizResult)
    {
        $quizResult->delete();

        return redirect()->route('quiz_results.index')
            ->with('success', 'Quiz result deleted successfully!');
    }
}

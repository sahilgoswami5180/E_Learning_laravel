<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\OtpVerificationMail;
use App\Mail\EmailVerificationMail;
use Twilio\Rest\Client;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Socialite;


class AuthController extends Controller
{
    // Show the registration form
    public function showRegisterForm()
    {
        // Check if the user is already authenticated
        if (Auth::check()) {
            return redirect()->route('home'); // or redirect()->route('dashboard');
        }

        // If not authenticated, show the registration form
        return view('auth.register');
    }

    // Handle registration and send OTP via both email and SMS
    public function register(Request $request)
    {
        // Validate the registration request with added rules
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'mobile' => 'required|string|max:15|unique:users,mobile_number|regex:/^(\+?[1-9]\d{1,14})$/', // Validates international phone numbers
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:8|confirmed',
        ], [
            'name.required' => 'Full name is required.',
            'name.string' => 'Name must be a valid string.',
            'name.max' => 'Name cannot exceed 255 characters.',
            'mobile.required' => 'Mobile number is required.',
            'mobile.max' => 'Mobile number cannot exceed 15 characters.',
            'mobile.unique' => 'This mobile number is already registered.',
            'mobile.regex' => 'Please enter a valid mobile number, including the country code.',
            'email.required' => 'Email address is required.',
            'email.email' => 'Please enter a valid email address.',
            'email.unique' => 'This email is already registered.',
            'password.required' => 'Password is required.',
            'password.min' => 'Password must be at least 8 characters long.',
            'password.confirmed' => 'Password confirmation does not match.',
        ]);

        // Hash the password
        $validated['password'] = Hash::make($validated['password']);
        $validated['role'] = 'user';

        // Store mobile number (make sure to store full phone number with country code)
        $validated['mobile_number'] = $validated['mobile']; // Store full phone number

        // Create the user
        $user = User::create($validated);

        // Generate OTP (6-digit random number)
        $otp = rand(100000, 999999);

        // Store the OTP in the database
        $user->otp = $otp;

        // Generate email verification token
        $emailVerificationToken = Str::random(32);  // Generate a unique 32 character token
        $user->email_verification_token = $emailVerificationToken;
        $user->save();

        // Store OTP in the session for later validation
        session(['otp' => $otp, 'otp_email' => $user->email, 'otp_sent_at' => Carbon::now()]);

        // Send OTP to user's email
        Mail::to($user->email)->send(new OtpVerificationMail($otp));

        // Send OTP via SMS using Twilio
        $this->sendOtpSms($user->mobile_number, $otp);

        // Send email verification link
        $this->sendVerificationEmail($user, $emailVerificationToken);

        // Return response based on request type (AJAX or normal)
        if ($request->ajax()) {
            return response()->json([
                'status' => 'success',
                'message' => 'Registration successful! Please check your email and phone for the OTP to verify your account.',
            ]);
        }

        // Redirect to OTP verification page with a success message (non-AJAX)
        return redirect()->route('auth.verify-otp')
            ->with('success', 'Registration successful! Please check your email and phone for the OTP to verify your account.');
    }


    // Send OTP via Twilio SMS
    private function sendOtpSms($phoneNumber, $otp)
    {
        // Get Twilio credentials from the environment file
        $sid = env('TWILIO_SID');
        $token = env('TWILIO_AUTH_TOKEN');
        $twilioNumber = env('TWILIO_PHONE_NUMBER');

        // Create a Twilio client
        $client = new Client($sid, $token);

        try {
            // Send SMS using Twilio API
            $client->messages->create(
                $phoneNumber, // The phone number to send the OTP to
                [
                    'from' => $twilioNumber, // Your Twilio phone number
                    'body' => "Your OTP is: $otp" // The OTP message
                ]
            );
            Log::info("OTP sent successfully to $phoneNumber");
        } catch (\Exception $e) {
            // Handle Twilio exceptions (e.g., invalid phone number)
            Log::error('Twilio SMS Error: ' . $e->getMessage());
        }
    }

    // Send the email verification email with the token
    private function sendVerificationEmail($user, $token)
    {
        // Generate the verification URL with the token
        $verificationUrl = route('auth.verify-email', ['token' => $token]);

        // Send the verification email
        Mail::to($user->email)->send(new EmailVerificationMail($user, $verificationUrl));  // Pass user and verification URL
    }

    // Show the email verification form
    public function verifyEmail($token)
    {
        $user = User::where('email_verification_token', $token)->first();

        if (!$user) {
            return redirect()->route('login')->withErrors(['email' => 'Invalid or expired verification token.']);
        }

        // Mark the email as verified
        $user->email_verified_at = Carbon::now();
        $user->email_verification_token = null;  // Remove the token after verification
        $user->save();

        return redirect()->route('login')->with('success', 'Your email has been successfully verified! You can now log in.');
    }
    public function showResetPasswordForm()
    {
        return view('auth.reset-password');
    }
    // Show the login form
    public function showLoginForm()
    {
        if (Auth::check()) {
            if (Auth::user()->role == 'admin') {
                return redirect()->route('admin.dashboard');
            } elseif (Auth::user()->role == 'user') {
                return redirect()->route('student.index');
            } elseif (Auth::user()->role == 'instructor') {
                return redirect()->route('instructor.dashboard');
            }
        }

        return view('auth.login');
    }

    // Handle login
    public function login(Request $request)
    {
        // Validate the incoming request data
        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8|max:13',
        ], [
            'email.required' => 'Email address is required.',
            'email.email' => 'Please enter a valid email address.',
            'password.required' => 'Password is required.',
            'password.min' => 'Password must be at least 8 characters.',
            'password.max' => 'Password cannot exceed 13 characters.',
        ]);

        // Attempt login with provided credentials
        if (Auth::attempt(['email' => $validated['email'], 'password' => $validated['password']], $request->filled('remember'))) {
            $request->session()->regenerate();

            // Get the authenticated user
            $user = Auth::user();

            // Check if email is verified
            if ($user->email_verified_at === null) {
                // If email is not verified, log out the user and send an error message
                Auth::logout();
                return back()->withErrors(['email' => 'Your email is not verified. Please check your inbox and verify your email.']);
            }

            // Check if OTP is verified
            if ($user->otp_verified_at === null) {
                // If OTP is not verified, redirect to OTP verification page
                return redirect()->route('auth.verify-otp')->withErrors(['otp' => 'Please verify your mobile number by entering the OTP sent to your phone.']);
            }

            // If both email and OTP are verified, proceed with the login flow
            if ($user->role == 'admin') {
                session()->flash('success', 'Welcome back, Admin!');
                return redirect()->route('admin.dashboard');  // Redirect to Admin Dashboard
            } elseif ($user->role == 'instructor') {
                session()->flash('success', 'Welcome back, Instructor!');
                return redirect()->route('instructor.dashboard');  // Redirect to Instructor Dashboard
            } elseif ($user->role == 'user') {
                session()->flash('success', 'Welcome back, Student!');
                return redirect()->route('student.index');  // Redirect to Student Dashboard
            } else {
                // In case of other roles that shouldn't access the area
                Auth::logout();
                return back()->withErrors(['email' => 'You do not have permission to access this area.']);
            }
        }

        // If authentication fails, return with an error
        return back()->withErrors(['email' => 'Invalid email or password. Please try again.']);
    }

    // Handle logout
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')->with('success', 'You have been logged out successfully.');
    }

    // Show the OTP verification form
    public function showOtpVerifyForm()
    {
        return view('auth.verify-otp');
    }

    // Verify OTP
    public function verifyOtp(Request $request)
    {
        // Validate OTP input
        $validated = $request->validate([
            'otp' => 'required|digits:6', // Ensures exactly 6 digits
        ]);

        // Retrieve the OTP stored in the session
        $sessionOtp = session('otp');
        $otp = $validated['otp'];

        // Check if OTP from session matches the one entered by the user
        if (!$sessionOtp || $sessionOtp != $otp) {
            return back()->withErrors(['otp' => 'Invalid OTP. Please try again.']);
        }

        // Retrieve the user based on the session email
        $user = User::where('email', session('otp_email'))->first();

        if (!$user) {
            return back()->withErrors(['otp' => 'User not found.']);
        }

        // Mark the user's phone number as verified
        $user->otp_verified_at = Carbon::now();
        $user->save();

        // Clean up session data
        session()->forget(['otp', 'otp_email', 'otp_sent_at']);

        return redirect()->route('login')->with('success', 'Your phone number has been successfully verified! Please log in.');
    }


    // Resend OTP
    public function resendOtp(Request $request)
    {
        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return back()->withErrors(['email' => 'User not found.']);
        }

        $lastOtpSent = session('otp_sent_at');
        if ($lastOtpSent && Carbon::now()->diffInSeconds($lastOtpSent) < 30) {
            return back()->withErrors(['email' => 'You can resend the OTP after 30 seconds.']);
        }

        $otp = rand(100000, 999999);
        $user->otp = $otp;
        $user->save();

        session(['otp' => $otp, 'otp_email' => $user->email, 'otp_sent_at' => Carbon::now()]);

        Mail::to($user->email)->send(new OtpVerificationMail($otp));

        return back()->with('success', 'Verification OTP has been sent again.');
    }

    // Show user profile
    public function show()
    {
        $user = Auth::user();
        return view('auth.profile', compact('user'));
    }

    // Update profile image
    public function updateImage(Request $request)
    {
        // Validate the incoming request, allowing images up to 5MB in size
        $request->validate([
            'profile_image' => 'required|image|mimes:jpeg,png,jpg|max:5120', // Allowing max size of 5MB
        ]);

        $user = Auth::user();

        // If the user already has a profile image, delete the old one
        if ($user->profile_image && Storage::exists('public/' . $user->profile_image)) {
            Storage::delete('public/' . $user->profile_image);
        }

        // Store the new profile image and get its path
        $imagePath = $request->file('profile_image')->store('profile_images', 'public');

        // Update the user's profile image field with the new path
        $user->profile_image = $imagePath;
        $user->save();

        // Redirect the user back to their profile page with a success message
        return redirect()->route('profile')->with('success', 'Profile image updated successfully!');
    }

    public function updateuserImage(Request $request)
    {
        // Validate the incoming request, allowing images up to 5MB in size
        $request->validate([
            'profile_image' => 'required|image|mimes:jpeg,png,jpg|max:5120', // Allowing max size of 5MB
        ]);

        $user = Auth::user();

        // If the user already has a profile image, delete the old one
        if ($user->profile_image && Storage::exists('public/' . $user->profile_image)) {
            Storage::delete('public/' . $user->profile_image);
        }

        // Store the new profile image and get its path
        $imagePath = $request->file('profile_image')->store('profile_images', 'public');

        // Update the user's profile image field with the new path
        $user->profile_image = $imagePath;
        $user->save();

        // Redirect the user back to their profile page with a success message
        return redirect()->route('userprofile')->with('success', 'Profile image updated successfully!');
    }

    public function userprofileshow()
    {
        $user = Auth::user(); // Get the authenticated user
        return view('user.userprofile', compact('user'));
    }


    public function checkUserExistence(Request $request)
    {
        $email = $request->query('email');
        $user = User::where('email', $email)->first();

        return response()->json([
            'exists' => $user ? true : false
        ]);
    }
}

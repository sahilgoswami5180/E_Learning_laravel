<?php

namespace App\Http\Controllers;

use App\Models\Lesson;
use App\Models\Course;
use Illuminate\Http\Request;

class LessonController extends Controller
{
    /**
     * Display a listing of lessons with optional search and trashed filter.
     */
    public function index(Request $request)
    {
        // Start the query builder to fetch lessons with the course relationship
        $lessons = Lesson::with('course') // Eager load the course relation
            // Apply course title filter if 'course_title' query parameter is provided
            ->when($request->course_title, function ($query) use ($request) {
                $query->whereHas('course', function ($q) use ($request) {
                    $q->where('title', 'like', '%' . $request->course_title . '%');
                });
            })
            // Apply lesson title filter if 'lesson_title' query parameter is provided
            ->when($request->lesson_title, function ($query) use ($request) {
                $query->where('title', 'like', '%' . $request->lesson_title . '%');
            })
            // Apply trashed filter if 'trashed' query parameter is provided
            ->when($request->has('trashed'), function ($query) {
                // If 'trashed' is true, get only soft-deleted lessons
                $query->onlyTrashed();
            }, function ($query) {
                // If no 'trashed' parameter, get only active lessons (not deleted)
                $query->whereNull('deleted_at');
            })
            // Paginate the results with 10 lessons per page
            ->paginate(10);

        // Pass the lessons data and request input to the view
        return view('lesson.index', compact('lessons'));
    }
    /**
     * Show the form for creating a new lesson.
     */
    public function create()
    {
        // Fetch all courses to allow selecting a course when creating a lesson
        $courses = Course::all();
        return view('lesson.create', compact('courses'));
    }

    /**
     * Store a newly created lesson in the database.
     */
    public function store(Request $request)
    {
        // Validate the input data
        $request->validate([
            'course_id' => 'required|exists:courses,id',
            'title' => 'required|string|max:255',
            'content' => 'nullable|string',
            'content_type' => 'nullable|string|max:50', // Validate content_type
            'video_url' => 'nullable|url',
        ]);

        // Create the lesson and save it to the database
        Lesson::create($request->all());

        // Redirect back to the lessons index with a success message
        return redirect()->route('lessons.index')->with('success', 'Lesson added successfully!');
    }

    /**
     * Show the form for editing an existing lesson.
     */
    public function edit($id)
    {
        // Find the lesson by its ID
        $lesson = Lesson::findOrFail($id);
        // Fetch all courses for updating the course
        $courses = Course::all();
        return view('lesson.edit', compact('lesson', 'courses'));
    }

    /**
     * Update the specified lesson in the database.
     */
    public function update(Request $request, $id)
    {
        // Find the lesson by its ID
        $lesson = Lesson::findOrFail($id);

        // Validate the input data
        $request->validate([
            'course_id' => 'required|exists:courses,id',
            'title' => 'required|string|max:255',
            'content' => 'nullable|string',
            'content_type' => 'nullable|string|max:50',
            'video_url' => 'nullable|url',
        ]);

        // Update the lesson with the new data
        $lesson->update($request->all());

        // Redirect back to the lessons index with a success message
        return redirect()->route('lessons.index')->with('success', 'Lesson updated successfully!');
    }

    /**
     * Display the specified lesson.
     */
    public function show($id)
    {
        // Fetch the lesson with its related course
        $lesson = Lesson::with('course')->findOrFail($id);
        return view('lesson.show', compact('lesson'));
    }

    /**
     * Soft delete the specified lesson.
     */
    public function destroy($id)
    {
        // Find the lesson and soft delete it
        $lesson = Lesson::findOrFail($id);
        $lesson->delete();

        // Redirect back to the lessons index with a success message
        return redirect()->route('lessons.index')->with('success', 'Lesson deleted successfully!');
    }

    /**
     * Display a list of trashed (soft-deleted) lessons.
     */
    public function trashed()
    {
        // Fetch only trashed (soft-deleted) lessons
        $lessons = Lesson::onlyTrashed()->with('course')->get();
        return view('lesson.trashed', compact('lessons'));
    }

    /**
     * Restore a soft-deleted lesson.
     */
    public function restore($id)
    {
        // Find the soft-deleted lesson and restore it
        $lesson = Lesson::onlyTrashed()->findOrFail($id);
        $lesson->restore();

        // Redirect back to the lessons index with a success message
        return redirect()->route('lessons.index')->with('success', 'Lesson restored successfully!');
    }

    /**
     * Permanently delete a soft-deleted lesson.
     */
    public function forceDelete($id)
    {
        // Find the soft-deleted lesson and permanently delete it
        $lesson = Lesson::onlyTrashed()->findOrFail($id);
        $lesson->forceDelete();

        // Redirect back to trashed lessons view with a success message
        return redirect()->route('lessons.trashed')->with('success', 'Lesson permanently deleted!');
    }
}

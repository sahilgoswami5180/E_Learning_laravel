<?php

namespace App\Http\Controllers;

use App\Models\Question;
use App\Models\Quiz;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    // Display a listing of all questions (including soft-deleted ones)
    public function index(Request $request)
    {
        $query = Question::with('quiz'); // Start the query with the 'quiz' relationship

        // Filter by trashed or active questions
        if ($request->has('trashed')) {
            $query->onlyTrashed(); // Show trashed questions
        }

        // Filter by quiz ID
        if ($request->has('quiz_id') && $request->quiz_id !== '') {
            $query->where('quiz_id', $request->quiz_id);
        }

        // Filter by question text (case-insensitive partial search)
        if ($request->has('question_text') && $request->question_text !== '') {
            $query->where('question_text', 'like', '%' . $request->question_text . '%');
        }

        // Paginate the results
        $questions = $query->paginate(10); // Paginate the filtered results

        // Get all quizzes for the filter dropdown (if applicable)
        $quizzes = Quiz::all();

        // Pass the filtered questions and quizzes to the view
        return view('questions.index', compact('questions', 'quizzes'));
    }

    // Show the form for creating a new question
    public function create()
    {
        $quizzes = Quiz::all(); // Fetch all quizzes to associate with the question
        return view('questions.create', compact('quizzes'));
    }

    // Store a new question
    public function store(Request $request)
    {
        // Validate the input data
        $request->validate([
            'quiz_id' => 'required|exists:quizzes,id',
            'question_text' => 'required|string|max:255',
            'options' => 'required|array|min:2',
            'correct_answer' => 'required|string',
        ]);

        // Ensure there are at least two options
        if (empty($request->options) || count($request->options) < 2) {
            return redirect()->back()->with('error', 'Please provide at least two options.')->withInput();
        }

        // Prepare the data and store the new question
        $data = $request->all();
        // Implode the options array into a comma-separated string
        $data['options'] = implode(',', $request->options);

        Question::create($data);

        // Redirect back with success message
        return redirect()->route('questions.index')->with('success', 'Question created successfully!');
    }

    // Update an existing question
    public function update(Request $request, $id)
    {
        $question = Question::findOrFail($id); // Fetch the question by ID

        // Validate the input data
        $request->validate([
            'quiz_id' => 'required|exists:quizzes,id',
            'question_text' => 'required|string|max:255',
            'options' => 'required|array|min:2',
            'correct_answer' => 'required|string',
        ]);

        // Ensure there are at least two options
        if (empty($request->options) || count($request->options) < 2) {
            return redirect()->back()->with('error', 'Please provide at least two options.')->withInput();
        }

        // Prepare the data and update the question
        $request->merge([
            'options' => implode(',', $request->options),
        ]);

        $question->update([
            'quiz_id' => $request->quiz_id,
            'question_text' => $request->question_text,
            'options' => $request->options,
            'correct_answer' => $request->correct_answer,
        ]);

        // Redirect back with success message
        return redirect()->route('questions.index')->with('success', 'Question updated successfully!');
    }

    // Show the specified question
    public function show($id)
    {
        $question = Question::with('quiz')->findOrFail($id); // Fetch the question with its quiz

        // Split the options string into an array
        $options = explode(',', $question->options);
        // Trim the options to remove extra spaces
        $options = array_map('trim', $options);

        return view('questions.show', compact('question', 'options'));
    }

    // Show the form for editing the specified question
    public function edit($id)
    {
        $question = Question::findOrFail($id);
        $quizzes = Quiz::all();

        // Split the options string into an array
        $options = explode(',', $question->options); // Comma-separated options

        return view('questions.edit', compact('question', 'quizzes', 'options'));
    }


    // Soft delete the specified question
    public function destroy($id)
    {
        $question = Question::findOrFail($id);
        $question->delete(); // This performs a soft delete

        return redirect()->route('questions.index')->with('success', 'Question deleted successfully!');
    }

    // Restore a soft-deleted question
    public function restore($id)
    {
        $question = Question::withTrashed()->findOrFail($id); // Fetch trashed question
        $question->restore(); // Restore the soft-deleted question

        return redirect()->route('questions.index')->with('success', 'Question restored successfully!');
    }

    // Permanently delete a soft-deleted question
    public function forceDelete($id)
    {
        $question = Question::withTrashed()->findOrFail($id); // Fetch trashed question
        $question->forceDelete(); // Permanently delete the question

        return redirect()->route('questions.index')->with('success', 'Question permanently deleted!');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\ContactUs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller
{
    // Mark all notifications as read
    public function markAllAsRead(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Get all unread notifications
        $notifications = ContactUs::where('read', false)->get();

        // Mark each as read
        foreach ($notifications as $notification) {
            $notification->read = true;
            $notification->save();
        }


        return redirect()->back()->with('success', 'All notifications marked as read.');
    }

    // Clear all notifications (soft delete)
    public function clearAll(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Get all read notifications
        $notifications = ContactUs::where('read', true)->get();

        // Soft delete each notification
        foreach ($notifications as $notification) {
            $notification->delete();  // Soft delete
        }


        return redirect()->back()->with('success', 'All notifications cleared.');
    }
}

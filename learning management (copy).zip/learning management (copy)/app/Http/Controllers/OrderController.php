<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\StreamedResponse;

class OrderController extends Controller
{
    /**
     * Display a listing of the orders.
     */
    public function index(Request $request)
    {
        if (!Auth::check()) {
            return redirect()->route('home');
        }

        // Fetch categories for filter options
        $categories = Category::all();

        // Start building the query for orders
        $query = Order::with('user', 'category'); // Assuming 'user' and 'category' relationships are set up

        // Apply search filter if search term exists
        if ($request->has('search') && $request->search != '') {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%');
            });
        }

        // Apply category filter
        if ($request->has('category_id') && $request->category_id != '') {
            $query->where('category_id', $request->category_id);
        }

        // Apply status filter
        if ($request->has('status') && $request->status != '') {
            $query->where('status', $request->status);
        }

        // Fetch the filtered orders, paginated
        $orders = $query->paginate(5);

        // Return the view with orders and categories
        return view('order.index', compact('orders', 'categories'));
    }

    public function store(Request $request)
    {
        // Order creation logic...
        $order = Order::create([
            // Your order data here...
            'status' => 'new',  // Mark the order as new
        ]);

        // Redirect after creating the order
        return redirect()->route('user.index');  // Or wherever you need to redirect
    }


    /**
     * Show the form for editing the specified order.
     */
    public function edit(Order $order)
    {
        if (!Auth::check()) {
            return redirect()->route('home');
        }

        return view('order.edit', compact('order'));
    }

    /**
     * Update the specified order in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:active,inactive',
        ]);

        $order = Order::findOrFail($id);
        $order->update($request->all());

        return redirect()->route('orders.index')->with('success', 'Order updated successfully.');
    }

    /**
     * Soft delete the specified order.
     */
    public function destroy(Order $order)
    {
        if (!Auth::check()) {
            return redirect()->route('home');
        }

        try {
            $order->delete();
            session()->flash('success', 'Order deleted successfully!');
        } catch (\Exception $e) {
            session()->flash('error', 'Failed to delete order.');
        }

        return redirect()->route('orders.index');
    }

    /**
     * Restore the specified soft-deleted order.
     */
    public function restore($id)
    {
        if (!Auth::check()) {
            return redirect()->route('home');
        }

        $order = Order::withTrashed()->findOrFail($id);
        $order->restore();

        session()->flash('success', 'Order restored successfully!');
        return redirect()->route('orders.index');
    }

    /**
     * Update order status (active/inactive).
     */
    public function updateStatus(Order $order)
    {
        if (!Auth::check()) {
            return redirect()->back()->with('error', 'Unauthorized');
        }

        $order->status = $order->status === 'active' ? 'inactive' : 'active';
        $order->save();

        return redirect()->route('orders.index')->with('success', 'Order status updated successfully.');
    }

    /**
     * Display the specified order.
     */
    public function show($id)
    {
        if (!Auth::check()) {
            return redirect()->route('home');
        }

        // Eager load 'user', 'category', and 'order_items' relationships
        $order = Order::with('user', 'category', 'order_items')->findOrFail($id);
        // dd($order);

        return view('order.show', compact('order'));
    }


    /**
     * Display orders in a card layout.
     */
    public function card()
    {
        $orders = Order::paginate(8); // Show 8 orders per page
        return view('order.card-view', compact('orders'));
    }

    /**
     * Show the list of deleted orders.
     */
    public function deleted()
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'You must be logged in to view deleted orders.');
        }

        $deletedOrders = Order::onlyTrashed()->get();

        return view('order.deleted', compact('deletedOrders'));
    }

    /**
     * Export orders data as a CSV file.
     */
    public function exportToCsv()
    {
        if (!Auth::check()) {
            return redirect()->route('home');
        }

        $fileName = 'trashed_orders_' . date('Ymd_His') . '.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$fileName\"",
        ];

        $callback = function () {
            $fileHandle = fopen('php://output', 'w');

            // Add CSV header row
            fputcsv($fileHandle, ['ID', 'User Name', 'Total', 'Status', 'Category', 'Created At', 'Updated At', 'Deleted At']);

            // Fetch only soft-deleted orders (trashed orders)
            $trashedOrders = Order::withTrashed()->with('category')->get();

            // Loop through the trashed orders and add them to the CSV
            foreach ($trashedOrders as $order) {
                $deletedAt = $order->deleted_at ? $order->deleted_at->format('M j, Y, g:i a') : 'Not Deleted';

                // Write order data to CSV
                fputcsv($fileHandle, [
                    $order->id,
                    $order->user->name ?? 'N/A',
                    $order->total,
                    ucfirst($order->status),
                    $order->category->name ?? 'N/A',
                    $order->created_at->format('M j, Y, g:i a'),
                    $order->updated_at->format('M j, Y, g:i a'),
                    $deletedAt,  // Format deleted_at or show 'N/A'
                ]);
            }

            fclose($fileHandle);
        };

        return new StreamedResponse($callback, 200, $headers);
    }

    /**
     * Export orders data as a PDF.
     */
    public function exportToPdf()
    {
        if (!Auth::check()) {
            return redirect()->route('home');
        }

        // Fetch all orders data, including those that are soft deleted
        $orders = Order::with('category')->get();

        // Separate orders into deleted and non-deleted
        $nonDeletedOrders = $orders->whereNull('deleted_at');
        $deletedOrders = Order::onlyTrashed()->get();

        // Prepare the data for rendering in the PDF
        $html = view('orders.pdf', compact('nonDeletedOrders', 'deletedOrders'))->render();

        // Configure Dompdf options
        $options = new \Dompdf\Options();
        $options->set('isHtml5ParserEnabled', true); // Enable HTML5 parsing
        $options->set('isPhpEnabled', true); // Allow PHP function calls for URLs
        $options->set('isRemoteEnabled', true); // Allow loading remote images

        $dompdf = new \Dompdf\Dompdf($options);
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'landscape');
        $dompdf->render();

        // Stream the generated PDF
        return $dompdf->stream('orders_' . date('Ymd_His') . '.pdf', [
            'Attachment' => true,
        ]);
    }
}

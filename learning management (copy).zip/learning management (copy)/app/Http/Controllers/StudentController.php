<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\CourseOrder;
use App\Models\PaymentSuccess;
use App\Models\Quiz;
use App\Models\QuizResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Exception;

class StudentController extends Controller
{
    /**
     * Display a listing of the courses.
     */
    public function index(Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login')->with('error', 'Please log in to access the courses.');
        }

        $courses = Course::all(); // Fetch all available courses

        return view('student.index', compact('courses'));
    }

    /**
     * Show course details.
     */
    public function course_detail_show($id)
    {
        // Fetch course details with lessons and quizzes
        $course = Course::with(['lessons', 'quizzes'])->findOrFail($id);

        // Check if the user has paid for this course
        $isPaid = CourseOrder::where('user_id', Auth::id())
            ->where('course_id', $course->id)
            ->where('status', 'completed') // Ensure status is 'paid'
            ->exists();

        return view('student.course_details', compact('course', 'isPaid'));
    }

    /**
     * Show the quiz details.
     */
    public function showQuiz($quizId)
    {
        $quiz = Quiz::with('course', 'questions')->findOrFail($quizId);
        $questions = $quiz->questions;
        $course = $quiz->course;

        // Ensure the user is authenticated before proceeding
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Please login to access this quiz.');
        }

        // Ensure the user has paid for the course this quiz belongs to
        $hasAccess = CourseOrder::where('user_id', Auth::id())
            ->where('course_id', $course->id)
            ->where('status', 'completed') // Ensuring the course is paid for
            ->exists();

        if (!$hasAccess) {
            return redirect()->route('student.index')->with('error', 'You need to purchase the course to access this quiz.');
        }

        // Check if the user has already completed this quiz
        $quizResult = QuizResult::where('quiz_id', $quizId)
            ->where('user_id', Auth::id())
            ->where('completed', 1) // Check if quiz is marked as completed
            ->first();

        if ($quizResult) {
            // If the quiz is completed, pass quizResult to the view
            return view('student.quiz_show', compact('quiz', 'course', 'questions', 'quizResult'));
        }

        // Otherwise, pass quizResult as null
        return view('student.quiz_show', compact('quiz', 'course', 'questions', 'quizResult'));
    }

    /**
     * Submit the quiz and calculate the score.
     */
    public function submitQuiz(Request $request, $quizId)
    {
        // Fetch the quiz and its associated questions
        $quiz = Quiz::with('questions')->findOrFail($quizId);
        $questions = $quiz->questions;

        // Validate the submitted answers
        $answers = $request->input('answers');
        $score = 0;
        $totalQuestions = count($questions);

        // Loop through each question and check the answer
        foreach ($questions as $question) {
            // Check if the answer is correct (you should store the correct answer in your database)
            if (isset($answers[$question->id]) && $answers[$question->id] == $question->correct_answer) {
                $score++;
            }
        }

        // Save the quiz result
        $quizResult = QuizResult::create([
            'user_id' => Auth::id(),
            'quiz_id' => $quizId,
            'score' => $score,
            'total_questions' => $totalQuestions,
            'completed' => 1,
        ]);

        // Redirect to the result page with the score
        return redirect()->route('student.quiz.result', $quizId)->with('score', $score)->with('total_questions', $totalQuestions);
    }

    /**
     * Show quiz result.
     */
    public function showResult($quizId)
    {
        $quiz = Quiz::findOrFail($quizId);
        $quizResult = QuizResult::where('user_id', Auth::id())->where('quiz_id', $quizId)->first();

        // Pass the result and quiz to the view
        return view('student.quiz_result', compact('quiz', 'quizResult'));
    }
}

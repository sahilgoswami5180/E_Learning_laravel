<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ContactUs extends Model
{
    use HasFactory, SoftDeletes; // Add SoftDeletes here

    protected $fillable = [
        'name',
        'email',
        'message',
        'read',
    ];

    // Optionally, add a scope for unread messages
    public function scopeUnread($query)
    {
        return $query->where('read', false);
    }
    public function replies()
    {
        return $this->hasMany(Reply::class);
    }
}

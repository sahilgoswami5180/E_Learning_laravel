<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CourseOrder extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'course_id',
        'total',
        'status',
        'razorpay_order_id',
        'payment_status',
        'razorpay_payment_id',   // New field
        'razorpay_signature',     // New field
        'course_name',            // New field (optional, store the course name if needed)
    ];

    /**
     * Get the user that owns the course order.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the course that the order is associated with.
     */
    public function course()
    {
        return $this->belongsTo(Course::class);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Course extends Model
{
    use HasFactory, SoftDeletes; // Add SoftDeletes trait

    // Specify fillable columns
    protected $fillable = ['title', 'description', 'duration', 'price', 'instructor_id'];

    /**
     * Relationship: Course belongs to an instructor (User).
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function instructor()
    {
        return $this->belongsTo(User::class, 'instructor_id');
    }

    public function lessons()
    {
        return $this->hasMany(Lesson::class);
    }

    // Relationship with Quizzes
    public function quizzes()
    {
        return $this->hasMany(Quiz::class);
    }
}

<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ChangePasswordController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\ComboController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeletedCategoryController;
use App\Http\Controllers\DeletedComboController;
use App\Http\Controllers\DeletedProductController;
use App\Http\Controllers\DeletedSubcategoryController;
use App\Http\Controllers\InstructorController;
use App\Http\Controllers\LessonController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\RazorpayController;
use App\Http\Controllers\SubcategoryController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserDetailsController;
use App\Http\Controllers\QuizController;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\QuizResultController;
use App\Http\Controllers\ProgressController;

use App\Models\ContactUs;
use Illuminate\Support\Facades\Route;

// dd('sd');


// Routes outside auth middleware
Route::get('/', [AuthController::class, 'showLoginForm'])->name('home'); // Home route
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');

// Registration routes
Route::get('register', [AuthController::class, 'showRegisterForm'])->name('register.form');
Route::post('register', [AuthController::class, 'register'])->name('register');
Route::get('/email/verify/{token}', [AuthController::class, 'verifyEmail'])->name('auth.verify-email');
Route::get('/check-user-existence', [AuthController::class, 'checkUserExistence']);

// Login and logout routes
Route::post('login', [AuthController::class, 'login'])->name('login');
Route::post('logout', [AuthController::class, 'logout'])->name('logout');


// Password reset routes
Route::get('forgot-password', [PasswordResetController::class, 'showForgotPasswordForm'])->name('forgot.password');
Route::post('forgot-password', [PasswordResetController::class, 'sendResetLink'])->name('password.email');
Route::get('password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
Route::post('password/reset', [PasswordResetController::class, 'reset'])->name('password.update');

// Routes inside auth middleware

// OTP Verification routes
Route::get('otp/verify', [AuthController::class, 'showOtpVerifyForm'])->name('auth.verify-otp');
Route::post('otp/verify', [AuthController::class, 'verifyOtp'])->name('otp.verify');
Route::post('otp/resend', [AuthController::class, 'resendOtp'])->name('otp.resend');

// Password reset routes
Route::get('password/reset', [AuthController::class, 'showResetPasswordForm'])->name('auth.reset-password.page');
Route::post('password/reset', [AuthController::class, 'resetPassword'])->name('auth.reset-password');


Route::middleware(['auth'])->group(function () {


    Route::get('/admin', [AdminController::class, 'index'])->name('admin.dashboard');

    // Course Management
    Route::resource('course', CourseController::class);
    Route::get('/course', [CourseController::class, 'index'])->name('course.index');
    Route::get('/course/create', [CourseController::class, 'create'])->name('course.create');
    Route::post('/course', [CourseController::class, 'store'])->name('course.store');
    Route::get('/course/{id}', [CourseController::class, 'show'])->name('course.show');
    Route::get('/course/{id}/edit', [CourseController::class, 'edit'])->name('course.edit');
    Route::put('/course/{id}', [CourseController::class, 'update'])->name('course.update');
    Route::delete('/course/{id}', [CourseController::class, 'destroy'])->name('course.destroy');
    Route::post('/courses/{id}/restore', [CourseController::class, 'restore'])->name('courses.restore');
    Route::delete('/courses/{id}/force-delete', [CourseController::class, 'forceDelete'])->name('courses.forceDelete');
    // Instructor Dashboard Route
    Route::get('/instructor/dashboard', [InstructorController::class, 'index'])->name('instructor.dashboard');
    Route::resource('lessons', LessonController::class);
    Route::get('lessons', [LessonController::class, 'index'])->name('lessons.index');
    Route::get('lessons/create', [LessonController::class, 'create'])->name('lessons.create');
    Route::post('lessons', [LessonController::class, 'store'])->name('lessons.store');
    Route::get('lessons/{id}/edit', [LessonController::class, 'edit'])->name('lessons.edit');
    Route::put('lessons/{id}', [LessonController::class, 'update'])->name('lessons.update');
    Route::get('lessons/{id}', [LessonController::class, 'show'])->name('lessons.show');
    Route::delete('lessons/{id}', [LessonController::class, 'destroy'])->name('lessons.destroy');
    Route::get('lessons/trashed', [LessonController::class, 'trashed'])->name('lessons.trashed');
    Route::post('lessons/{id}/restore', [LessonController::class, 'restore'])->name('lessons.restore');
    Route::delete('lessons/{id}/force', [LessonController::class, 'forceDelete'])->name('lessons.forceDelete');




    // Quizzes Routes
    Route::get('quizzes', [QuizController::class, 'index'])->name('quizzes.index'); // List all quizzes
    Route::get('quizzes/create', [QuizController::class, 'create'])->name('quizzes.create'); // Show form to create quiz
    Route::post('quizzes', [QuizController::class, 'store'])->name('quizzes.store'); // Store a new quiz
    Route::get('quizzes/{quiz}', [QuizController::class, 'show'])->name('quizzes.show'); // Show a specific quiz
    Route::get('quizzes/{quiz}/edit', [QuizController::class, 'edit'])->name('quizzes.edit'); // Show form to edit quiz
    Route::put('quizzes/{quiz}', [QuizController::class, 'update'])->name('quizzes.update'); // Update a quiz
    Route::post('quizzes/{quiz}/restore', [QuizController::class, 'restore'])->name('quizzes.restore');
    Route::delete('quizzes/{quiz}/delete', [QuizController::class, 'destroy'])->name('quizzes.delete');
    Route::delete('/quizzes/{quiz}/permanent-delete', [QuizController::class, 'forceDelete'])->name('quizzes.permanentDelete');

    // Questions Routes
    Route::get('questions', [QuestionController::class, 'index'])->name('questions.index');
    Route::get('questions/create', [QuestionController::class, 'create'])->name('questions.create');
    Route::post('questions', [QuestionController::class, 'store'])->name('questions.store');
    Route::get('questions/{id}', [QuestionController::class, 'show'])->name('questions.show');
    Route::get('questions/{id}/edit', [QuestionController::class, 'edit'])->name('questions.edit');
    Route::put('questions/{id}', [QuestionController::class, 'update'])->name('questions.update');
    Route::delete('questions/{id}', [QuestionController::class, 'destroy'])->name('questions.destroy');
    Route::post('questions/{id}/restore', [QuestionController::class, 'restore'])->name('questions.restore');
    Route::delete('questions/{id}/forceDelete', [QuestionController::class, 'forceDelete'])->name('questions.forceDelete');

    // Quiz Results Routes
    Route::get('quiz-results', [QuizResultController::class, 'index'])->name('quiz_results.index'); // List all quiz results
    Route::get('quiz-results/create', [QuizResultController::class, 'create'])->name('quiz_results.create'); // Show form to create quiz result
    Route::post('quiz-results', [QuizResultController::class, 'store'])->name('quiz_results.store'); // Store a quiz result
    Route::get('quiz-results/{quizResult}', [QuizResultController::class, 'show'])->name('quiz_results.show'); // Show a specific quiz result
    Route::get('quiz-results/{quizResult}/edit', [QuizResultController::class, 'edit'])->name('quiz_results.edit'); // Show form to edit quiz result
    Route::put('quiz-results/{quizResult}', [QuizResultController::class, 'update'])->name('quiz_results.update'); // Update a quiz result
    Route::delete('quiz-results/{quizResult}', [QuizResultController::class, 'destroy'])->name('quiz_results.destroy'); // Delete a quiz result
    Route::get('quiz/{quizId}/result', [StudentController::class, 'showResult'])->name('student.quiz.result');

    // Progress Routes
    Route::get('progress', [ProgressController::class, 'index'])->name('progress.index'); // List all progress records
    Route::get('progress/create', [ProgressController::class, 'create'])->name('progress.create'); // Show form to create progress
    Route::post('progress', [ProgressController::class, 'store'])->name('progress.store'); // Store progress record
    Route::get('progress/{progress}', [ProgressController::class, 'show'])->name('progress.show'); // Show specific progress
    Route::get('progress/{progress}/edit', [ProgressController::class, 'edit'])->name('progress.edit'); // Show form to edit progress
    Route::put('progress/{progress}', [ProgressController::class, 'update'])->name('progress.update'); // Update progress
    Route::delete('progress/{progress}', [ProgressController::class, 'destroy'])->name('progress.destroy'); // Delete progress


    // Student Dashboard Route
    Route::get('/student/dashboard', [StudentController::class, 'index'])->name('student.index');
    Route::get('/courses/{id}', [StudentController::class, 'course_detail_show'])->name('course.show');
    Route::get('/checkout/{courseId}', [RazorpayController::class, 'checkout'])->name('razorpay.checkout');
    Route::get('/payment/success', [RazorpayController::class, 'paymentSuccess'])->name('payment.success');
    Route::get('/payment/cancel', [RazorpayController::class, 'paymentCancel'])->name('razorpay.payment.cancel');
    Route::post('/student/quiz/{quizId}/submit', [StudentController::class, 'submitQuiz'])->name('student.quiz.submit');
    Route::get('/student/quiz/{quizId}', [StudentController::class, 'showQuiz'])->name('student.quiz_show');

    // Dashboard and user-related routes
    // Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('index', [UserController::class, 'index'])->name('user.index');
    Route::get('shop', [UserController::class, 'shop'])->name('shop.index');

    // Route::get('/checkout', [CheckoutController::class, 'index'])->name('user.checkout');
    // Route::post('/checkout/cod', [CheckoutController::class, 'codCheckout'])->name('checkout.cod');
    // Route::post('/razorpay/order/create', [CheckoutController::class, 'createRazorpayOrder'])->name('razorpay.order.create');
    // Route::post('/checkout/process', [CheckoutController::class, 'process'])->name('checkout.process');
    // Route::post('/checkout/success', [CheckoutController::class, 'success'])->name('checkout.success');
    // Route::get('/checkout/cancel', [CheckoutController::class, 'cancel'])->name('checkout.cancel');

    // Route::get('product/{id}', [UserController::class, 'showproducts'])->name('shop.product_details');
    // Route::get('shop/combos', [UserController::class, 'seemorecombos'])->name('shop.combos');
    // Route::get('combo/{id}', [UserController::class, 'showcombos'])->name('shop.combo_details');


    Route::get('/search', [UserController::class, 'index'])->name('user.search');
    Route::post('/delete-account', [UserController::class, 'deleteAccount'])->name('delete.account');


    // Change password routes
    Route::get('/change-password', [ChangePasswordController::class, 'showChangePasswordForm'])->name('change-password.form');
    Route::post('/change-password', [ChangePasswordController::class, 'updatePassword'])->name('change-password.update');

    // Change password routes for user
    Route::get('/user/change-password', [ChangePasswordController::class, 'showuserChangePasswordForm'])->name('userchange-password.form');
    Route::post('/user/change-password', [ChangePasswordController::class, 'updatePassword'])->name('change-password.update');
    // User profile routes
    Route::get('/profile', [AuthController::class, 'show'])->name('profile');
    Route::get('/myprofile', [AuthController::class, 'userprofileshow'])->name('userprofile');


    // user_details routes

    // Resourceful routes for user details (index, create, store, show, edit, update, destroy)
    Route::resource('user_details', UserDetailsController::class);
    Route::get('user_details', [UserDetailsController::class, 'index'])->name('user_details.index');
    // Soft Delete, Restore, and Force Delete routes
    // These are custom routes not included by default in a resource controller
    Route::post('user_details/{id}/softdelete', [UserDetailsController::class, 'softDelete'])->name('user_details.softDelete');
    Route::post('user_details/{id}/restore', [UserDetailsController::class, 'restore'])->name('user_details.restore');
    Route::delete('user_details/{id}/forceDelete', [UserDetailsController::class, 'forceDelete'])->name('user_details.forceDelete');
    Route::patch('/users/{user}/toggle-role', [UserController::class, 'toggleRole'])->name('user.toggleRole');

    Route::get('orders', [UserController::class, 'showOrders'])->name('user.orders');
    Route::get('/orders/{order}', [UserController::class, 'showOrderDetails'])->name('user.myorder-details');

    // Wishlist Section
    Route::get('/wishlist', [UserController::class, 'showWishlist'])->name('shop.wishlist');
    // Wishlist Routes
    // Add product to wishlist (POST)
    Route::post('wishlist/add/{product}', [UserController::class, 'addWishlist'])->name('wishlist.add');

    // Remove product from wishlist (DELETE)
    Route::delete('wishlist/remove/{product}', [UserController::class, 'removeWishlist'])->name('wishlist.remove');



    // Support Section
    // Display support page (GET request)
    Route::get('/profile/support', [UserController::class, 'showSupport'])->name('user.support');

    // Handle form submission (POST request)
    Route::post('/profile/support', [UserController::class, 'storeSupport'])->name('user.support.store');
    Route::get('/About-us', [UserController::class, 'Aboutus'])->name('user.about-us');
    Route::get('/Blog', [UserController::class, 'Blog'])->name('user.blog');


    // FAQ Section
    Route::get('/profile/faq', [UserController::class, 'showFAQ'])->name('user.faq');

    Route::put('/profile/image', [AuthController::class, 'updateImage'])->name('profile.update.image');
    Route::put('/profile/userimage', [AuthController::class, 'updateuserImage'])->name('profile.update.userimage');

    Route::resource('order', OrderController::class);
    Route::post('order/{order}/edit', [OrderController::class, 'update'])->name('order.edit');
    Route::get('/contact-us', [ContactUsController::class, 'create'])->name('user.contact-us');
    Route::post('/contact-us', [ContactUsController::class, 'store']);
    Route::get('/dashboard/contact-msg', [DashboardController::class, 'dashboard'])->name('dashboard.contact-msg');
    Route::post('/contact-msg/{id}/read', [ContactUsController::class, 'markAsRead'])->name('contact-msg.mark-as-read');
    Route::post('/contact-msg/mark-all-as-read', [NotificationController::class, 'markAllAsRead'])->name('contact-msg.mark-all-as-read');
    Route::delete('/contact-msg/clear-all', [NotificationController::class, 'clearAll'])->name('contact-msg.clear-all');
    Route::delete('/contact-msg/delete-selected', [ContactUsController::class, 'deleteSelected'])->name('contact-msg.delete-selected');
    Route::post('reply/{id}', [ContactUsController::class, 'reply'])->name('contact-msg.reply');
    Route::get('/inbox', function () {
        $contactUsSubmissions = ContactUs::all();
        return view('inbox', compact('contactUsSubmissions'));
    })->name('inbox');

    // Fallback Route for undefined routes
    Route::fallback(function () {
        return response()->view('errors.404', [], 404);
    });
});

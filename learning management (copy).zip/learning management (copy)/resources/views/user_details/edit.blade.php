@extends('layouts.app')

@section('title', 'Edit User')

@section('content')
<style>
    .readonly {
        cursor: not-allowed;
        background-color: gray;
        color: black;
    }
</style>
<div class="container mx-auto min-h-screen">
    <!-- Breadcrumb Navigation -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <li class="inline-flex items-center">
                <a href="{{ route('admin.dashboard') }}"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="{{ route('user_details.index') }}"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Users</a>
                </div>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Edit
                        User_Details</span>
                </div>
            </li>
        </ol>
    </div>

    <form action="{{ route('user_details.update', $user->id) }}" method="POST"
        class="bg-white shadow-lg rounded-lg px-8 py-2 space-y-6">
        @csrf
        @method('PUT')
        <h4 class="text-xl font-semibold text-gray-800 mb-8">Edit User</h4>
        <!-- Role Field (Editable) -->
        <div class="mb-4 relative" style="width: 490px;">
            <label for="role" class="block text-sm font-medium text-gray-700">Role<span
                    class="text-red-500">*</span></label>
            <select id="role" name="role"
                class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                required>
                <option value="admin" {{ old('role', $user->role) == 'admin' ? 'selected' : '' }}>Admin</option>
                <option value="user" {{ old('role', $user->role) == 'user' ? 'selected' : '' }}>User</option>
                <option value="instructor" {{ old('role', $user->role) == 'instructor' ? 'selected' : '' }}>instructor
                </option>

            </select>
            @error('role')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
            @enderror
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <!-- Name Field (View-Only) -->
            <div class="mb-4 relative">
                <label for="name" class="block text-sm font-medium text-gray-700">Name </label>
                <div
                    class="mt-2 flex items-center justify-between px-4 py-2 border border-gray-300 rounded-xl shadow-lg bg-white hover:bg-gray-50 transition duration-300 ease-in-out">
                    <span class="text-lg font-semibold text-gray-800">Name:</span>
                    <span class="text-xl font-bold text-blue-600">{{ old('name', $user->name) }}</span>
                </div>
                @error('name')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Email Field (View-Only) -->
            <div class="mb-4 relative">
                <label for="email" class="block text-sm font-medium text-gray-700">Email </label>
                <div
                    class="mt-2 flex items-center justify-between px-4 py-2 border border-gray-300 rounded-xl shadow-lg bg-white hover:bg-gray-50 transition duration-300 ease-in-out">
                    <span class="text-lg font-semibold text-gray-800">Email:</span>
                    <span class="text-xl font-bold text-blue-600">{{ old('email', $user->email) }}</span>
                </div>
                @error('email')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Mobile Number Field (View-Only) -->
            <div class="mb-4 relative">
                <label for="mobile_number" class="block text-sm font-medium text-gray-700">Mobile Number</label>
                <div
                    class="mt-2 flex items-center justify-between px-4 py-2 border border-gray-300 rounded-xl shadow-lg bg-white hover:bg-gray-50 transition duration-300 ease-in-out">
                    <span class="text-lg font-semibold text-gray-800">Mobile Number:</span>
                    <span class="text-xl font-bold text-blue-600">{{ old('mobile_number', $user->mobile_number)
                        }}</span>
                </div>

                @error('mobile_number')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>



            <!-- Password Field (Editable) -->
            <div class="mb-4 relative">
                <label for="password" class="block text-sm font-medium text-gray-700">Password<span
                        class="text-red-500">*</span></label>
                <input type="password" id="password" name="password"
                    class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Leave blank to keep the current password">
                @error('password')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- OTP Field (View-Only) -->
            <div class="mb-4 relative">
                <label for="otp" class="block text-sm font-medium text-gray-700">OTP</label>
                <div
                    class="mt-2 flex items-center justify-between px-4 py-2 border border-gray-300 rounded-xl shadow-lg bg-white hover:bg-gray-50 transition duration-300 ease-in-out">
                    <span class="text-lg font-semibold text-gray-800">OTP:</span>
                    <span class="text-xl font-bold text-blue-600" id="otp_display">{{ old('otp', $user->otp) }}</span>
                </div>
                <input type="hidden" name="otp" id="otp" value="{{ old('otp', $user->otp) }}">
            </div>

            <!-- Profile Image Field (View-Only) -->
            <div class="mb-4 relative">
                <label for="profile_image" class="block text-sm font-medium text-gray-700">Profile Image</label>
                <img src="{{ asset('storage/' . (old('profile_image', $user->profile_image) ?? 'profile_images/Profile.png')) }}"
                    alt="Profile Image" class="rounded-lg w-32 h-32 object-cover">


            </div>
        </div>

        <!-- Submit Button -->
        <div class="flex justify-between items-center">
            <button type="submit"
                class="px-6 py-3 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200 ease-in-out">
                Update User
            </button>
            <a href="{{ route('user_details.index') }}"
                class="px-6 py-3 bg-gray-600 text-white rounded-lg shadow-md hover:bg-gray-700 focus:ring-4 focus:ring-gray-300 transition duration-200 ease-in-out">
                Back to Users List
            </a>
        </div>
    </form>
</div>
@endsection
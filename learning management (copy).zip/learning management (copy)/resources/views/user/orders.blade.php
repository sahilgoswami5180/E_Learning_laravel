@extends('layouts.user')

@section('content')
    <div class="container mx-auto my-8 px-4">
        <h2 class="text-3xl font-semibold text-gray-900 mb-8">My Orders</h2>

        @if ($orders->isEmpty())
            <div class="text-center text-gray-600">
                <p class="text-lg mb-4">You haven't placed any orders yet. Start shopping now!</p>
                <a href="{{ route('user.index') }}"
                    class="inline-block px-8 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition duration-300 ease-in-out shadow-lg transform hover:scale-105">Shop
                    Now</a>
            </div>
        @else
            <div class="overflow-x-auto bg-white shadow-lg rounded-lg border border-gray-200">
                <table class="min-w-full text-sm text-gray-700">
                    <thead class="bg-blue-50 border-b">
                        <tr>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Order Date</th>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Total Amount</th>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Status</th>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($orders as $order)
                            <tr class="border-b hover:bg-gray-50 transition duration-300 ease-in-out hover:shadow-lg">
                                <td class="py-3 px-6 text-gray-800">{{ $order->created_at->format('M j, Y') }}</td>
                                <td class="py-3 px-6 font-semibold text-gray-900">${{ number_format($order->total, 2) }}
                                </td>
                                <td class="py-3 px-6">
                                    <span
                                        class="px-3 py-1 rounded-full text-sm
        {{ $order->status == 'pending'
            ? ' text-yellow-600'
            : ($order->status == 'paid'
                ? ' text-green-700'
                : ($order->status == 'cash on delivery'
                    ? ' text-blue-600'
                    : 'bg-red-200 text-red-700')) }}
        font-medium">
                                        {{ ucfirst($order->status) }}
                                    </span>
                                </td>

                                <td class="py-3 px-6">
                                    <a href="{{ route('user.myorder-details', $order->id) }}"
                                        class="text-blue-600 hover:text-blue-800 font-medium hover:underline transition duration-300 ease-in-out">
                                        View Details
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

            </div>
        @endif
    </div>
@endsection

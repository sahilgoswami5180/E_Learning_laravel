<!-- resources/views/user/order-details.blade.php -->
@extends('layouts.user')

@section('content')
    <div class="container  mx-auto my-8 px-4">
        <h2 class="text-3xl font-semibold text-gray-800 mb-6">Order Details - #{{ $order->id }}</h2>

        <div class="bg-white shadow-lg rounded-lg p-6">
            <h3 class="text-xl font-semibold text-gray-700">Order Summary</h3>
            <p class="mt-2 text-gray-600">Ordered on: {{ $order->created_at->format('M j, Y') }}</p>
            <p class="mt-2 text-gray-600">Total Amount: ${{ number_format($order->total, 2) }}</p>

            <div class="mt-4">
                <h4 class="text-lg font-semibold text-gray-800">Order Items</h4>
                <table class="min-w-full mt-4 bg-gray-50 border border-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-3 px-4 text-left">Product Name</th>
                            <th class="py-3 px-4 text-left">Quantity</th>
                            <th class="py-3 px-4 text-left">Price</th>
                            <th class="py-3 px-4 text-left">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($order->items as $item)
                            <tr class="border-b hover:bg-gray-100">
                                <td class="py-3 px-4">{{ $item->product->name }}</td>
                                <td class="py-3 px-4">{{ $item->quantity }}</td>
                                <td class="py-3 px-4">${{ number_format($item->price, 2) }}</td>
                                <td class="py-3 px-4">${{ number_format($item->quantity * $item->price, 2) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="mt-6">
                <h4 class="text-lg font-semibold text-gray-800">Shipping Address</h4>
                <p class="text-gray-600">{{ $order->shipping_address }}</p>
            </div>

            <div class="mt-6">
                <h4 class="text-lg font-semibold text-gray-800">Order Status</h4>
                <span
                    class="px-3 py-1 rounded-full text-sm
        {{ $order->status == 'pending'
            ? 'bg-yellow-200 text-yellow-600'
            : ($order->status == 'paid'
                ? 'bg-green-200 text-green-600'
                : ($order->status == 'cash on delivery'
                    ? 'bg-blue-200 text-blue-600'
                    : 'bg-red-200 text-red-600')) }}">
                    {{ ucfirst($order->status) }}
                </span>
            </div>


            <div class="mt-6">
                <a href="{{ route('user.orders') }}"
                    class="inline-block px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">Back to
                    Orders</a>
            </div>
        </div>
    </div>
@endsection

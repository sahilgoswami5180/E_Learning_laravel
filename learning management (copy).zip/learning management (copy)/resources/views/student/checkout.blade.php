@extends('layouts.user')

@section('title', 'Checkout')

@section('content')
<div class="container mx-auto mt-5">
    <h1 class="text-3xl font-semibold mb-5">Checkout</h1>

    <div class="bg-white shadow-md rounded-lg p-6 mb-6">
        <h2 class="text-2xl font-semibold mb-3">Course Details</h2>
        <p><strong>Course:</strong> {{ $course->title }}</p>
        <p><strong>Price:</strong> ${{ number_format($course->price, 2) }}</p>
        <p><strong>Instructor:</strong> {{ $course->instructor->name ?? 'Not Assigned' }}</p>
    </div>

    <form action="{{ route('student.checkout') }}" method="POST">
        @csrf
        <input type="hidden" name="course_id" value="{{ $course->id }}">

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Cash on Delivery Option -->
            <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center">
                <h3 class="text-lg font-medium mb-2">Cash on Delivery</h3>
                <p class="text-gray-600">Pay when you receive the course access.</p>
                <button type="submit" name="payment_method" value="cod"
                    class="bg-green-500 text-white px-6 py-3 rounded-md mt-4 hover:bg-green-600">
                    Pay with COD
                </button>
            </div>

            <!-- Razorpay Payment Option -->
            <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center">
                <h3 class="text-lg font-medium mb-2">Razorpay</h3>
                <p class="text-gray-600">Secure online payment using Razorpay.</p>
                <button type="submit" name="payment_method" value="razorpay"
                    class="bg-yellow-500 text-white px-6 py-3 rounded-md mt-4 hover:bg-yellow-600">
                    Pay with Razorpay
                </button>
            </div>
        </div>
    </form>
</div>
@endsection
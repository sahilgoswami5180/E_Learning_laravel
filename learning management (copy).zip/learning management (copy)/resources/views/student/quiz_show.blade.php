@extends('layouts.student')

@section('title', $quiz->title)

@section('content')
<div class="container mx-auto mt-5 px-4 sm:px-6 lg:px-8">
    <!-- Title and Information -->
    <h1 class="text-3xl font-semibold text-gray-800 mb-4">{{ $quiz->title }}</h1>
    <p class="text-gray-600 mb-4">Course: <span class="font-semibold text-gray-800">{{ $course->title }}</span></p>
    <p class="text-gray-600 mb-4">Number of Questions: <span class="font-semibold text-gray-800">{{ $questions->count()
            }}</span></p>

    @if ($quizResult && $quizResult->completed == 1)
    <!-- If quiz is completed, show result -->
    <div class="bg-green-500 text-white p-4 rounded-lg mb-6">
        <p class="font-medium">You have already completed this quiz!</p>
        <p class="text-sm">Your score: <span class="font-semibold">{{ $quizResult->score }} / {{
                $questions->count() }} </span></p>

        <p class="text-sm">You cannot retake this quiz. If you need assistance, please contact support.</p>

        <!-- Feedback based on score -->
        @if ($quizResult->score == $quizResult->total_questions)
        <p class="text-white mt-2">Excellent! You got a perfect score!</p>
        @elseif ($quizResult->score >= $quizResult->total_questions * 0.7)
        <p class="text-white mt-2">Good job! You're on the right track.</p>
        @else
        <p class="text-white mt-2">Don't worry! Keep practicing and you'll do better next time.</p>
        @endif
    </div>
    @else
    <!-- Quiz Form (if quiz is not completed) -->
    <form action="{{ route('student.quiz.submit', $quiz->id) }}" method="POST" class="space-y-8">
        @csrf

        @foreach ($questions as $index => $question)
        <div class="bg-white p-6 rounded-lg shadow-md">
            <p class="text-xl font-medium text-gray-700 mb-4">{{ $index + 1 }}. {{ $question->question_text }}</p>
            <div class="space-y-4">
                @php
                // Convert the comma-separated options string back into an array
                $options = explode(',', $question->options);
                @endphp

                @foreach ($options as $option)
                <div class="flex items-center">
                    <input type="radio" name="answers[{{ $question->id }}]" value="{{ $option }}"
                        class="form-radio text-blue-500 rounded-full w-5 h-5 focus:ring-blue-300">
                    <label class="ml-3 text-gray-600 text-lg">{{ $option }}</label>
                </div>
                @endforeach
            </div>
        </div>
        @endforeach

        <!-- Submit Button -->
        <div class="flex justify-center mt-8">
            <button type="submit"
                class="bg-blue-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-blue-700 transition duration-200 transform hover:scale-105">
                Submit Quiz
            </button>
        </div>
    </form>
    @endif
</div>
@endsection
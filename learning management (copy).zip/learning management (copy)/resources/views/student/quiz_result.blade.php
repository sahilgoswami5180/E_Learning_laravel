@extends('layouts.student')

@section('title', 'Quiz Result')

@section('content')
<div class="container mx-auto mt-5 px-4 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-semibold text-gray-800 mb-5">Quiz Result</h1>

    <div class="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 class="text-2xl font-semibold text-gray-700 mb-4">{{ $quiz->title }}</h2>
        <p class="text-gray-600">Course: <span class="font-semibold text-gray-800">{{ $quiz->course->title }}</span></p>

        <div class="mt-4">
            <p class="text-lg text-gray-700">Your Score: <span class="text-xl font-semibold text-green-600">{{
                    $quizResult->score }} / {{ $quizResult->total_questions }}</span></p>

           
           
        </div>

        <!-- Optionally show detailed results -->
        <div class="mt-6">
            <h3 class="text-lg font-semibold text-gray-700">Detailed Results</h3>
            <ul class="list-none mt-3">
                @foreach ($quiz->questions as $question)
                <li class="border-b border-gray-200 py-2">
                    <p class="text-gray-800">{{ $loop->iteration }}. {{ $question->question_text }}</p>
                    <p class="text-gray-600">Your Answer: {{ $question->user_answer ? $question->user_answer : 'Not
                        answered' }}</p>
                    <p class="text-gray-600">Correct Answer: {{ $question->correct_answer }}</p>
                    <p
                        class="text-gray-600 {{ $question->user_answer == $question->correct_answer ? 'text-green-500' : 'text-red-500' }}">
                        {{ $question->user_answer == $question->correct_answer ? 'Correct' : 'Incorrect' }}
                    </p>
                </li>
                @endforeach
            </ul>
        </div>
    </div>
</div>
@endsection
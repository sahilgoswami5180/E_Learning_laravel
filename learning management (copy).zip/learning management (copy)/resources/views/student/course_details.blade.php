@extends('layouts.student')

@section('title', $course->title)

@section('content')
<div class="container mx-auto mt-10 px-6">
    <!-- Course Title (Always displayed) -->
    <h1 class="text-4xl font-semibold text-gray-800 mb-8 text-center">{{ $course->title }}</h1>

    @if ($isPaid)
        <!-- Course Overview (Only shown if paid) -->
        <div class="bg-white shadow-lg rounded-lg p-8 mb-8">
            <p class="text-gray-600 text-lg mb-4">Duration: <strong>{{ $course->duration }} hours</strong></p>
            <p class="text-gray-600 text-lg mb-4">Price: <strong>${{ number_format($course->price, 2) }}</strong></p>
            <p class="text-gray-600 text-lg mb-4">
                Instructor: <strong>{{ $course->instructor->name ?? 'Not Assigned' }}</strong>
            </p>
            <p class="text-gray-600 text-lg mb-6">{{ $course->description }}</p>
        </div>

        <!-- Lessons Section (Only shown if paid) -->
        <div class="bg-white shadow-lg rounded-lg p-8 mb-8">
            <h2 class="text-3xl font-semibold text-gray-800 mb-6">Lessons</h2>
            <ul class="list-none space-y-6">
                @foreach ($course->lessons as $lesson)
                    <li>
                        <div class="bg-gray-100 p-6 rounded-lg">
                            <!-- Dropdown Button -->
                            <button
                                class="w-full text-left flex justify-between items-center font-semibold text-gray-800 py-3 px-6 bg-gray-200 rounded-lg focus:outline-none"
                                data-toggle="lesson-{{ $lesson->id }}">
                                <span>{{ $lesson->title }}</span>
                                <span class="text-blue-500">+</span>
                            </button>

                            <!-- Dropdown Content -->
                            <div id="lesson-{{ $lesson->id }}"
                                class="lesson-content hidden mt-4 px-6 py-4 bg-gray-50 rounded-lg">
                                <div class="mt-4 text-gray-700">
                                    {!! $lesson->content !!}
                                </div>

                                <!-- Display lesson video -->
                                @if ($lesson->video_url)
                                    <div class="mt-4">
                                        <h3 class="text-xl font-semibold">Lesson Video</h3>
                                        <div class="aspect-w-16 aspect-h-9">
                                            <iframe class="w-full h-full rounded-lg" src="{{ $lesson->video_url }}" frameborder="0"
                                                allowfullscreen></iframe>
                                        </div>
                                    </div>
                                @endif

                                <!-- Quiz for the lesson (Only displayed if the lesson is completed) -->
                                @if ($lesson->is_completed)
                                    <div class="mt-4">
                                        <a href="{{ route('student.quiz', $lesson->id) }}"
                                            class="text-blue-500 underline hover:text-blue-700 transition duration-300">
                                            Take Quiz
                                        </a>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </li>
                @endforeach
            </ul>
        </div>

        <!-- Quizzes Section (Only shown if paid) -->
        <div class="bg-white shadow-lg rounded-lg p-8 mb-8">
            <h2 class="text-3xl font-semibold text-gray-800 mb-6">Quizzes</h2>
            <ul class="space-y-4">
                @foreach ($course->quizzes as $quiz)
                    <li class="text-lg">
                        <a href="{{ route('student.quiz_show', $quiz->id) }}"
                            class="text-blue-500 underline hover:text-blue-700 transition duration-300">
                            {{ $quiz->title }}
                        </a>
                    </li>
                @endforeach
            </ul>
        </div>

    @else
        <!-- Buy Now Section -->
        <div class="bg-white shadow-lg rounded-lg p-8 mb-8 text-center">
            <h2 class="text-3xl font-semibold text-gray-800 mb-6">Unlock Your Learning Journey</h2>
            <p class="text-lg text-gray-600 mb-6">Get full access to this course and start learning today!</p>

            <!-- Benefits Section -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
                <div class="flex items-center text-left">
                    <svg xmlns="http://www.w3.org/2000/svg"
                        class="h-6 w-6  border-blue-400 border-2 p-1 rounded-full text-blue-500 mr-4" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6h6" />
                    </svg>
                    <span class="text-lg text-gray-600">Lifetime Access</span>
                </div>
                <div class="flex items-center text-left">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 border-blue-400 border-2 p-1 text-blue-500 mr-4"
                        fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
                    <span class="text-lg text-gray-600">Comprehensive Curriculum</span>
                </div>
                <div class="flex items-center text-left">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6  border-blue-400 border-2 p-1 text-blue-500 mr-4"
                        fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                    <span class="text-lg text-gray-600">Expert Instructor Support</span>
                </div>
            </div>

            <!-- Call to Action Button -->
            <div class="flex justify-center">
                <a href="{{ route('razorpay.checkout', $course->id) }}"
                    class="text-center bg-blue-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-blue-700 transition duration-300 transform hover:scale-105">
                    Buy Now and Get Instant Access
                </a>
            </div>
        </div>
    @endif
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Toggle dropdown visibility on button click
        document.querySelectorAll('[data-toggle]').forEach(button => {
            button.addEventListener('click', () => {
                const lessonContent = document.getElementById(button.getAttribute('data-toggle'));
                const icon = button.querySelector('span.text-blue-500');

                if (lessonContent.classList.contains('hidden')) {
                    lessonContent.classList.remove('hidden');
                    icon.textContent = '−'; // Change + to −
                } else {
                    lessonContent.classList.add('hidden');
                    icon.textContent = '+'; // Change − to +
                }
            });
        });
    });
</script>

@endsection
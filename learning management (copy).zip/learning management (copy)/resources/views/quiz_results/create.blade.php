@extends('layouts.instructor')

@section('content')
<div class="container">
    <h1>Add Quiz Result</h1>
    <form action="{{ route('quiz_results.store') }}" method="POST">
        @csrf

        <div class="form-group">
            <label for="quiz_id">Select Quiz</label>
            <select name="quiz_id" id="quiz_id" class="form-control" required>
                <option value="" disabled selected>Select a quiz</option>
                @foreach($quizzes as $quiz)
                <option value="{{ $quiz->id }}">{{ $quiz->title }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label for="user_id">Select User</label>
            <select name="user_id" id="user_id" class="form-control" required>
                <option value="" disabled selected>Select a user</option>
                @foreach($users as $user)
                <option value="{{ $user->id }}">{{ $user->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label for="score">Score</label>
            <input type="number" name="score" id="score" class="form-control" min="0" max="100" required>
        </div>

        <div class="form-group">
            <label for="completed">Completed</label>
            <select name="completed" id="completed" class="form-control" required>
                <option value="" disabled selected>Select status</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Save</button>
    </form>
</div>
@endsection
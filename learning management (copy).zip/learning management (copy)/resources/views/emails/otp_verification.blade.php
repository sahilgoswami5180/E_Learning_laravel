<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification</title>
    <style>
        /* Tailwind CSS Import */
        @import url('https://cdn.jsdelivr.net/npm/tailwindcss@2.1.2/dist/tailwind.min.css');

        /* Custom styles for OTP email template */
        body {
            background-color: #fafafa;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .otp-container {
            background-color: #fafafa;
            text-align: center;
            width: 100%;
            padding: 0 16px;
        }

        .otp-box {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 32px;
            max-width: 600px;
            width: 100%;
            margin: 0 auto;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .otp-code {
            font-size: 32px;
            font-weight: 700;
            letter-spacing: 12px;
            background-color: #ebe3ff;
            padding: 16px;
            border-radius: 8px;
            color: #000000;
            margin-bottom: 24px;
        }

        .otp-text {
            font-size: 16px;
            color: #555555;
            margin-bottom: 16px;
        }

        .footer {
            font-size: 12px;
            color: #888888;
            margin-top: 32px;
            text-align: center;
        }

        .footer a {
            color: #888888;
            text-decoration: none;
        }

        .logo {
            width: 180px;
            height: auto;
        }

        /* Mobile responsive adjustments */
        @media only screen and (max-width: 600px) {
            .otp-box {
                padding: 16px;
            }

            .otp-code {
                font-size: 28px;
                letter-spacing: 8px;
                padding: 12px;
            }

            .otp-text {
                font-size: 14px;
                margin-bottom: 12px;
            }

            .footer {
                font-size: 10px;
            }

            /* Adjust logo size on smaller screens */
            .logo {
                width: 150px;
            }
        }

        /* Further adjustments for smaller screens (e.g., mobile phones) */
        @media only screen and (max-width: 480px) {
            .otp-box {
                padding: 12px;
            }

            .otp-code {
                font-size: 24px;
                letter-spacing: 6px;
                padding: 10px;
            }

            .otp-text {
                font-size: 12px;
                margin-bottom: 10px;
            }

            .footer {
                font-size: 10px;
            }

            .logo {
                width: 120px;
            }
        }
    </style>
</head>

<body>

    <!-- Main Email Container -->
    <div class="otp-container">

        <!-- OTP Box -->
        <div class="otp-box">
            <!-- Logo Section -->
            <div>
                <img src="https://i.imghippo.com/files/xZkvY1724649505.png" alt="Logo" class="logo" />
            </div>

            <!-- OTP Header -->
            <h1 class="text-3xl font-bold text-gray-900 mt-4">Please Confirm Your Mobile Number</h1>
            <p class="otp-text">Use this code to confirm your mobile number and complete your signup process.</p>

            <!-- OTP Code Display -->
            <div class="otp-code">
                {{ $otp }}
            </div>

            <!-- Instructions -->
            <p class="otp-text">This code is valid for 15 minutes. Please enter the OTP on the verification page to
                complete your registration.</p>

            <!-- Footer -->
            <div class="footer">
                <p>&copy; {{ date('Y') }} Rudresh Modi. All rights reserved.</p>
                <p><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </div>

</body>

</html>

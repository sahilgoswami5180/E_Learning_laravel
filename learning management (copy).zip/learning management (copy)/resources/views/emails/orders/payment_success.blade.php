@component('mail::message')
# Payment Successful

Your payment has been successfully processed.

**Order ID:** {{ $order->id }}
**Total Amount:** ${{ $order->total }}
**Payment Method:** Credit/Debit Card

Thank you for your purchase! Your order is being processed, and we will notify you once it's shipped.

Thanks,
{{ config('app.name') }}
@endcomponent
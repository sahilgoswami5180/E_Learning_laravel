<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Deletion Notice</title>

    <!-- Link to FontAwesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
            color: #333;
        }

        .container {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .header h1 {
            color: #2a9d8f;
            font-size: 24px;
            margin: 0;
        }

        .content {
            line-height: 1.6;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .content p {
            margin-bottom: 10px;
        }

        .content p strong {
            font-weight: bold;
        }

        .footer {
            text-align: center;
            font-size: 14px;
            color: #888;
        }

        .footer p {
            margin: 10px 0;
        }

        .cta-button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #2a9d8f;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
        }

        .cta-button:hover {
            background-color: #21867a;
        }

        .icon {
            font-size: 40px;
            color: #2a9d8f;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-user-slash icon"></i>
            <h1>Account Deletion Notice</h1>
        </div>

        <div class="content">
            <p>Hello, {{ $name }}</p>

            <p>
                We are notifying you that your account will be deleted on <strong>{{ $deletionTime }}</strong>.
                If you have any questions, please do not hesitate to <a href="mailto:support@example.com">contact
                    us</a>.
            </p>
            <p>
                If you change your mind or need more time, please let us know before the deletion date.
            </p>

            <a href="https://www.example.com" class="cta-button">
                Visit Our Help Center <i class="fas fa-info-circle"></i>
            </a>
        </div>

        <div class="footer">
            <p>Regards,</p>
            <p>The Team at Example.com</p>
            <p>
                <a href="https://www.example.com" style="color: #2a9d8f;">Visit our Website</a> |
                <a href="mailto:support@example.com" style="color: #2a9d8f;">Contact Support</a>
            </p>
        </div>
    </div>
</body>

</html>

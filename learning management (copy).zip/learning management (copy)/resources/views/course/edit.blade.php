@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Course</h1>
    <form action="{{ route('course.update', $course->id) }}" method="POST">
        <!-- Pass the course ID here -->
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="title">Course Title</label>
            <input type="text" name="title" id="title" class="form-control" value="{{ $course->title }}" required>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control" required>{{ $course->description }}</textarea>
        </div>
        <div class="form-group">
            <label for="duration">Duration (in hours)</label>
            <input type="number" name="duration" id="duration" class="form-control" value="{{ $course->duration }}"
                required>
        </div>
        <div class="form-group">
            <label for="price">Price (in USD)</label>
            <input type="number" name="price" id="price" class="form-control" value="{{ $course->price }}" step="0.01"
                required>
        </div>
        <div class="form-group">
            <label for="instructor_id">Assign Instructor</label>
            <select name="instructor_id" id="instructor_id" class="form-control">
                <option value="">None</option>
                @foreach ($instructors as $instructor)
                <option value="{{ $instructor->id }}" @if ($instructor->id == $course->instructor_id) selected @endif>
                    {{ $instructor->name }}
                </option>
                @endforeach
            </select>
        </div>
        <button type="submit" class="btn btn-success mt-3">Update Course</button>
    </form>
</div>
@endsection
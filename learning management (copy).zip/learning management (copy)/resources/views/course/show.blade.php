@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Course Details</h1>
    <div class="card">
        <div class="card-header">{{ $course->name }}</div>
        <div class="card-body">
            <p><strong>Description:</strong> {{ $course->description }}</p>
            <p><strong>Instructor:</strong> {{ $course->instructor ? $course->instructor->name : 'Not Assigned' }}</p>
        </div>
    </div>
    <a href="{{ route('course.index') }}" class="btn btn-secondary mt-3">Back to Courses</a>
</div>
@endsection
@extends('layouts.instructor')

@section('title', 'Add Question')

@section('content')

<div class="container mt-6 px-4">
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="{{ route('instructor.dashboard') }}"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>

            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="{{ route('questions.index') }}"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Questions</a>
                </div>
            </li>

            <!-- Current Page -->
            <li aria-current="page">
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Add Question</span>
                </div>
            </li>
        </ol>
    </div>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-xl">
        <!-- Flex container to align Button and Page Title -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-semibold text-gray-800 flex items-center">
                <i class="fas fa-plus-circle mr-2"></i> Add New Question
            </h2>
        </div>

        <!-- Form to Add Question -->
        <form action="{{ route('questions.store') }}" method="POST" class="space-y-6">
            @csrf

            <div class="grid grid-cols-2 gap-6">
                <!-- Quiz Selection -->
                <div>
                    <label for="quiz_id" class="block text-sm font-medium text-gray-700">
                        Select Quiz <span class="text-red-500">*</span>
                    </label>
                    <select name="quiz_id" id="quiz_id"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                        required>
                        <option value="">-- Select a Quiz --</option>
                        @foreach($quizzes as $quiz)
                        <option value="{{ $quiz->id }}">{{ $quiz->title }}</option>
                        @endforeach
                    </select>
                    @error('quiz_id')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Correct Answer Selection -->
                <div>
                    <label for="correct_answer" class="block text-sm font-medium text-gray-700">
                        Correct Answer <span class="text-red-500">*</span>
                    </label>
                    <select name="correct_answer" id="correct_answer"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required>
                        <option value="">-- Select the Correct Answer --</option>
                        <option value="Option 1">Option 1</option>
                        <option value="Option 2">Option 2</option>
                    </select>
                    @error('correct_answer')
                    <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Question Text -->
            <div>
                <label for="question_text" class="block text-sm font-medium text-gray-700">
                    Question Text <span class="text-red-500">*</span>
                </label>
                <textarea name="question_text" id="question_text"
                    class="mt-1 block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-200"
                    rows="4" required></textarea>
                @error('question_text')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                @enderror
            </div>

            <!-- Options Section -->
            <div>
                <label for="options" class="block text-sm font-medium text-gray-700">
                    Options <span class="text-red-500">*</span>
                </label>
                <div id="options-container">
                    <!-- Option 1 -->
                    <div class="option-input-container mb-4 relative">
                        <input type="text" name="options[]"
                            class="option-input w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-gray-500 text-gray-700 transition-all duration-300"
                            placeholder="Option 1" required>
                    </div>
                    <!-- Option 2 -->
                    <div class="option-input-container mb-4 relative">
                        <input type="text" name="options[]"
                            class="option-input w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-gray-500 text-gray-700 transition-all duration-300"
                            placeholder="Option 2" required>
                    </div>
                </div>
                <button type="button" id="add-option"
                    class="w-full bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 transition duration-300 flex items-center justify-center mt-4">
                    <i class="fas fa-plus-circle mr-2"></i> Add Option
                </button>
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end space-x-4 mt-6">
                <a href="{{ route('questions.index') }}"
                    class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <button type="submit"
                    class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                    <i class="fas fa-check-circle mr-2"></i> Add Question
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById('add-option').addEventListener('click', function() {
        const container = document.getElementById('options-container');
        const optionCount = container.children.length + 1;

        // Create new input for option
        const inputGroup = document.createElement('div');
        inputGroup.className = 'option-input-container mb-4 relative';
        inputGroup.innerHTML = `
            <input type="text" name="options[]"
                class="option-input w-full px-4 py-3 rounded-lg border border-gray-300 shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none placeholder-gray-500 text-gray-700 transition-all duration-300"
                placeholder="Option ${optionCount}" required>
            <div class="absolute top-0 right-0 mt-2 mr-2">
                <button type="button" class="text-gray-500 hover:text-red-600 transition-colors delete-btn">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        `;
        container.appendChild(inputGroup);

        // Add the new option to the correct answer dropdown
        const correctAnswerSelect = document.getElementById('correct_answer');
        const newOption = document.createElement('option');
        newOption.value = `Option ${optionCount}`;
        newOption.textContent = `Option ${optionCount}`;
        correctAnswerSelect.appendChild(newOption);

        // Update options dynamically based on user input
        inputGroup.querySelector('.option-input').addEventListener('input', function() {
            newOption.value = this.value;
            newOption.textContent = this.value;
        });

        // Delete option on button click
        inputGroup.querySelector('.delete-btn').addEventListener('click', function() {
            // Remove the input group
            inputGroup.remove();

            // Remove the corresponding option from the dropdown
            correctAnswerSelect.querySelector(`option[value="Option ${optionCount}"]`).remove();
        });
    });

    // Update existing options dynamically when edited
    document.querySelectorAll('.option-input').forEach(function(input, index) {
        input.addEventListener('input', function() {
            const correctAnswerSelect = document.getElementById('correct_answer');
            const optionToUpdate = correctAnswerSelect.options[index + 1]; // Adjust for placeholder
            optionToUpdate.value = this.value;
            optionToUpdate.textContent = this.value;
        });
    });
</script>

@endsection
<?php $__env->startSection('title', 'Add Lesson'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-6 px-4">
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('instructor.dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>

            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('lessons.index')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Lessons</a>
                </div>
            </li>

            <!-- Current Page -->
            <li aria-current="page">
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Add Lesson</span>
                </div>
            </li>
        </ol>
    </div>

    <!-- Full-Screen Width Card Container for the Form -->
    <div class="w-full bg-white p-8 rounded-lg shadow-xl">
        <!-- Flex container to align Button and Page Title -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-semibold text-gray-800 flex items-center">
                <i class="fas fa-plus-circle mr-2"></i> Add New Lesson
            </h2>
        </div>

        <!-- Form to Add Lesson -->
        <form action="<?php echo e(route('lessons.store')); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?>

            <!-- Course Selection -->
            <div>
                <label for="course_id" class="block text-sm font-medium text-gray-700">
                    Select Course <span class="text-red-500">*</span>
                </label>
                <select name="course_id" id="course_id"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required>
                    <option value="">-- Select a Course --</option>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Lesson Title -->
            <div>
                <label for="title" class="block text-sm font-medium text-gray-700">
                    Lesson Title <span class="text-red-500">*</span>
                </label>
                <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Content Type Selection -->
            <div>
                <label for="content_type" class="block text-sm font-medium text-gray-700">
                    Content Type <span class="text-red-500">*</span>
                </label>
                <select name="content_type" id="content_type"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required>
                    <option value="">-- Select Content Type --</option>
                    <option value="text">Text</option>
                    <option value="video">Video</option>
                </select>
            </div>

            <!-- Text Content -->
            <div id="text_content_group" style="display: none;">
                <label for="content" class="block text-sm font-medium text-gray-700">
                    Text Content<span class="text-red-500">*</span>
                <textarea name="content" id="content"required   
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('content')); ?></textarea>
            </div>

            <!-- Video URL -->
            <div id="video_url_group" style="display: none;">
                <label for="video_url" class="block text-sm font-medium text-gray-700">
                    Video URL <span class="text-red-500">*</span>
                </label>
                <input type="url" name="video_url" id="video_url" value="<?php echo e(old('video_url')); ?>"
                    class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <!-- Submit Button -->
            <div class="flex justify-end space-x-4 mt-6">
                <a href="<?php echo e(route('lessons.index')); ?>"
                    class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </a>
                <button type="submit"
                    class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                    <i class="fas fa-check-circle mr-2"></i> Add Lesson
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const contentType = document.getElementById('content_type');
        const textContentGroup = document.getElementById('text_content_group');
        const videoUrlGroup = document.getElementById('video_url_group');

        contentType.addEventListener('change', function () {
            // Hide all fields by default
            textContentGroup.style.display = 'none';
            videoUrlGroup.style.display = 'none';

            // Show relevant fields based on selection
            if (contentType.value === 'text') {
                textContentGroup.style.display = 'block';
            } else if (contentType.value === 'video') {
                videoUrlGroup.style.display = 'block';
            }
        });
    });
</script>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/lesson/create.blade.php ENDPATH**/ ?>
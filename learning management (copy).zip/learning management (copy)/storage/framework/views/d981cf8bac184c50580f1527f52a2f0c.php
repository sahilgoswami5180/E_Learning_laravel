<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Email Verification</title>
    <!-- Preconnect and stylesheet links -->
    <link rel="preconnect" href="https://unpkg.com">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.2.2/dist/css/bootstrap.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link
        href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300:400&family=Poppins:wght@300;500&display=swap"
        rel="stylesheet">
    <style>
        body {
            background-color: #f9f9f9;
            padding-right: 10px;
            padding-left: 10px;
            font-family: 'Open Sans', Helvetica, Arial, sans-serif;
            margin: 0;
        }

        .content {
            background-color: #ffffff;
            border: 1px solid #e5e5e5;
            border-radius: 8px;
            max-width: 600px;
            width: 100%;
            margin-top: 60px;
            margin-bottom: 30px;
            text-align: center;
            padding: 40px 20px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
            border-top: 4px solid #8e2de2;
        }

        h1 {
            color: #000;
            font-family: 'Poppins', sans-serif;
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        h2 {
            color: #888;
            font-family: 'Poppins', sans-serif;
            font-size: 18px;
            font-weight: 400;
            margin-bottom: 25px;
        }

        p {
            font-size: 14px;
            color: #666;
            line-height: 1.6;
            margin: 0 0 40px 0;
        }

        .btn-primary {
            background: linear-gradient(to right, #8e2de2, #4a00e0);
            color: white;
            border: none;
            font-family: 'Poppins', Helvetica, Arial, sans-serif;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            padding: 12px 30px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s ease, transform 0.2s ease;
            cursor: pointer;
        }

        .btn-primary:hover {
            background: linear-gradient(to right, #4a00e0, #8e2de2);
            transform: scale(1.05);
        }

        footer {
            text-align: center;
            margin-top: 40px;
            font-size: 12px;
            color: #bbb;
        }

        footer a {
            color: #bbb;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        small {
            display: block;
            margin-top: 10px;
            line-height: 18px;
        }

        .footer-links {
            margin-top: 15px;
        }

        .footer-links a {
            margin-right: 10px;
            color: #bbb;
        }

        / Mobile responsive adjustments / @media only screen and (max-width: 600px) {
            .content {
                padding: 20px 10px;
                margin-top: 20px;
                margin-bottom: 20px;
            }

            h1 {
                font-size: 24px;
            }

            h2 {
                font-size: 16px;
            }

            p {
                font-size: 13px;
            }

            .btn-primary {
                padding: 10px 25px;
                font-size: 14px;
            }

            footer {
                font-size: 10px;
            }

            .footer-links a {
                margin-right: 5px;
            }
        }

        / Further mobile adjustments / @media only screen and (max-width: 480px) {
            h1 {
                font-size: 22px;
            }

            h2 {
                font-size: 14px;
            }

            p {
                font-size: 12px;
            }

            .btn-primary {
                padding: 10px 20px;
                font-size: 12px;
            }

            footer {
                font-size: 9px;
            }

            small {
                font-size: 10px;
            }

            .footer-links a {
                font-size: 10px;
                margin-right: 5px;
            }
        }
    </style>
</head>

<body>

    <!-- Main Email Content -->
    <div class="d-flex justify-content-center">
        <div class="content">
            <!-- Welcome Section -->
            <h1>Hello, <?php echo e($userName); ?>!</h1>
            <h2>Verify Your Email Account</h2>
            <p>Thanks for creating your account on our platform! Please click the button below to validate your account
                and get started.</p>

            <!-- Verification Button -->
            <p><a href="<?php echo e($verificationUrl); ?>" target="_blank">Verify your email</a></p>
        </div>
    </div>

    <!-- Footer Section -->
    <footer>
        <small>Powered by Rudresh Modi | A lightweight Email template</small>
        <div class="footer-links">
            <a href="#" target="_blank">View Web Version</a> |
            <a href="#" target="_blank">Email Preferences</a> |
            <a href="#" target="_blank">Privacy Policy</a>
        </div>
        <small>If you have any questions, please contact us at <a href="mailto:support@example.com"
                mailto:target="_blank">support@example.com</a>.</small>
        <br>
        <small><a href="#" target="_blank">Unsubscribe</a> from our mailing lists.</small>
    </footer>

</body>

</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/razorpay/resources/views/emails/email_verification.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
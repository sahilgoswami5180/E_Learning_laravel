<?php $__env->startSection('content'); ?>

<!-- Success and Error Toasts -->
<?php if(session('success')): ?>
    <div id="successToast"
        class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
        <i class="fas fa-check-circle text-white text-2xl"></i>
        <span><?php echo e(session('success')); ?></span>
    </div>

    <script>
        setTimeout(() => {
            document.querySelector('#successToast').style.display = 'none';
        }, 4000);
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <div id="errorToast"
        class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
        <i class="fas fa-times-circle text-white text-2xl"></i>
        <span><?php echo e(session('error')); ?></span>
    </div>

    <script>
        setTimeout(() => {
            document.querySelector('#errorToast').style.display = 'none';
        }, 4000);
    </script>
<?php endif; ?>

<div class="container mx-auto top-0">
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>

            <!-- Courses Breadcrumb -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('course.index')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">
                        Courses
                    </a>
                </div>
            </li>
        </ol>
    </div>

    <!-- Filter Bar -->
    <div class="mb-4 p-4 bg-gray-50 rounded-lg shadow-md">
        <form action="<?php echo e(route('course.index')); ?>" method="GET" class="flex space-x-4">
            <!-- Filter by Course Title -->
            <div>
                <label for="title" class="block text-sm font-medium text-gray-600">Course Title</label>
                <input type="text" id="title" name="title" value="<?php echo e(request('title')); ?>"
                    class="mt-1 p-2 border border-gray-300 rounded-md w-full max-w-xs" placeholder="Search by Title">
            </div>

            <!-- Filter by Instructor -->
            <div>
                <label for="instructor" class="block text-sm font-medium text-gray-600">Instructor</label>
                <input type="text" id="instructor" name="instructor" value="<?php echo e(request('instructor')); ?>"
                    class="mt-1 p-2 border border-gray-300 rounded-md w-full max-w-xs"
                    placeholder="Search by Instructor">
            </div>

            <!-- Filter by Duration -->
            <div>
                <label for="duration" class="block text-sm font-medium text-gray-600">Duration (hours)</label>
                <input type="number" id="duration" name="duration" value="<?php echo e(request('duration')); ?>"
                    class="mt-1 p-2 border border-gray-300 rounded-md w-full max-w-xs" placeholder="Duration (hrs)">
            </div>

            <!-- Submit Button -->
            <div class="flex items-end">
                <button type="submit"
                    class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition duration-300 text-sm">
                    Filter
                </button>
                <a href="<?php echo e(route('course.index')); ?>"
                    class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                    <i class="fas fa-undo"></i>
                </a>
            </div>
        </form>
    </div>

    <!-- Action Buttons: Add New Course -->
    <div class="flex justify-end mb-4">
        <a href="<?php echo e(route('course.create')); ?>"
            class="bg-indigo-600 text-white px-4 py-2 rounded-full shadow-md hover:bg-indigo-700 transition duration-300 text-sm">
            Add New Course
        </a>
    </div>

    <!-- Courses Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Instructor</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Title</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Description</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Duration (hours)</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Price (USD)</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                        <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($course->id); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-800">
                            <?php echo e($course->instructor ? $course->instructor->name : 'Not Assigned'); ?>

                        </td>
                        <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($course->title); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-800"><?php echo e(Str::limit($course->description, 50)); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($course->duration); ?></td>
                        <td class="px-6 py-4 text-sm text-gray-800">$<?php echo e(number_format($course->price, 2)); ?></td>
                        <td class="px-6 py-4 text-sm text-center">
                            <div class="flex justify-center space-x-4">
                                <a href="<?php echo e(route('course.show', $course->id)); ?>"
                                    class="text-indigo-600 hover:text-indigo-800">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('course.edit', $course->id)); ?>" class="text-blue-600 hover:text-blue-800">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('course.destroy', $course->id)); ?>" method="POST"
                                    onsubmit="return confirm('Are you sure you want to delete this course?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:text-red-800">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        <?php echo e($courses->links('pagination::tailwind')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/course/index.blade.php ENDPATH**/ ?>
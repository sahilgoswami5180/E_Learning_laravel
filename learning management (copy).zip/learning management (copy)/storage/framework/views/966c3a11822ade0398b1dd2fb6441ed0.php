<?php $__env->startSection('content'); ?>

<!-- Success and Error Toasts -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>
<script>
    setTimeout(() => { document.querySelector('#successToast').style.display = 'none'; }, 4000);
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>
<script>
    setTimeout(() => { document.querySelector('#errorToast').style.display = 'none'; }, 4000);
</script>
<?php endif; ?>

<div class="container mx-auto mt-6">

    <!-- Breadcrumb Section -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700 mb-6"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('instructor.dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Quiz
                        Results</span>
                </div>
            </li>
        </ol>
    </div>

    <!-- Filter Bar -->
    <form action="<?php echo e(route('quiz_results.index')); ?>" method="GET"
        class="flex justify-between items-center mb-4 bg-gray-50 p-4 rounded-lg shadow-md">
        <div class="flex space-x-2 w-full max-w-3xl">
            <!-- Search input -->
            <input type="text" name="search" placeholder="Search by quiz or user..." value="<?php echo e(request()->search); ?>"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                style="width: 300px;">

            <!-- Status filter -->
            <select name="status"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm">
                <option value="">All Status</option>
                <option value="completed" <?php echo e(request()->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                <option value="incomplete" <?php echo e(request()->status == 'incomplete' ? 'selected' : ''); ?>>Incomplete</option>
            </select>

            <!-- Apply Filters button -->
            <button type="submit"
                class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 text-sm">
                <i class="fas fa-filter"></i> Apply Filters
            </button>

            <!-- Reset Filters -->
            <a href="<?php echo e(route('quiz_results.index')); ?>"
                class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                <i class="fas fa-undo"></i> Reset
            </a>
        </div>
    </form>

    <!-- Results Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Quiz</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">User</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Score</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Completed</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-colors duration-200">
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($loop->iteration); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($result->quiz->title); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($result->user->name); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($result->score); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($result->completed ? 'Yes' : 'No'); ?></td>
                    <td class="px-6 py-4 text-sm text-center">
                        <div class="flex justify-center space-x-3">
                            <a href="<?php echo e(route('quiz_results.show', $result->id)); ?>"
                                class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm">
                                View
                            </a>
                            <a href="<?php echo e(route('quiz_results.edit', $result->id)); ?>"
                                class="bg-yellow-500 text-white px-4 py-2 rounded-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-sm">
                                Edit
                            </a>
                            <form action="<?php echo e(route('quiz_results.destroy', $result->id)); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 text-sm"
                                    onclick="return confirm('Are you sure you want to delete this result?');">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        <?php echo e($results->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/quiz_results/index.blade.php ENDPATH**/ ?>
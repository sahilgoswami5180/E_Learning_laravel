<?php $__env->startSection('content'); ?>
<h2>Complete Your Payment</h2>
<form action="<?php echo e(route('checkout.success')); ?>" method="POST" id="razorpay-form">
    <?php echo csrf_field(); ?>
    <script src="https://checkout.razorpay.com/v1/checkout.js" data-key="<?php echo e(env('RAZORPAY_KEY')); ?>"
        data-amount="<?php echo e($finalTotal * 100); ?>" // Amount in paise data-currency="INR"
        data-order_id="<?php echo e($razorpayOrder->id); ?>" data-buttontext="Pay with Razorpay" data-name="Your Store Name"
        data-description="Order Payment" data-image="https://your-logo-url.com/logo.png"
        data-prefill.name="<?php echo e(Auth::user()->name); ?>" data-prefill.email="<?php echo e(Auth::user()->email); ?>"
        data-theme.color="#F37254" data-handler="razorpayPaymentHandler"></script>
    <input type="hidden" name="razorpay_order_id" value="<?php echo e($razorpayOrder->id); ?>">
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="razorpay_signature" id="razorpay_signature">
</form>

<script>
    function razorpayPaymentHandler(response) {
        // Get the payment ID and signature from the response
        document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
        document.getElementById('razorpay_signature').value = response.razorpay_signature;

        // Submit the form to the success route
        document.getElementById('razorpay-form').submit();
    }

    // Optional: Handle payment failure
    window.onerror = function (message, source, lineno, colno, error) {
        alert("Payment failed. Please try again.");
        console.error("Error occurred during payment: ", message);
    };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/razorpay/resources/views/user/razorpay.blade.php ENDPATH**/ ?>
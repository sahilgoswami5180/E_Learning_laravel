<?php $__env->startSection('content'); ?>

<!-- Success and Error Toasts -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>
<script>
    setTimeout(() => { document.querySelector('#successToast').style.display = 'none'; }, 4000);
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>
<script>
    setTimeout(() => { document.querySelector('#errorToast').style.display = 'none'; }, 4000);
</script>
<?php endif; ?>

<div class="container mx-auto mt-6">

    <!-- Breadcrumb Section -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700 mb-6"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('instructor.dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Quizzes</span>
                </div>
            </li>
        </ol>
        <div class="flex items-center justify-end ml-4">
            <a href="<?php echo e(route('quizzes.create')); ?>"
                class="bg-indigo-600 text-white px-4 py-2 rounded-full shadow-md hover:bg-indigo-700 transition duration-300 text-sm">
                Add New Quiz
            </a>

        </div>
    </div>

    <!-- Filter Bar -->
    <form action="<?php echo e(route('quizzes.index')); ?>" method="GET"
        class="flex justify-between items-center mb-4 bg-gray-50 p-4 rounded-lg shadow-md ">
        <div class="flex space-x-2 w-full max-w-3xl">
            <select name="course_id"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                style="width: 200px;">
                <option value="">All Courses</option>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($course->id); ?>" <?php echo e(request()->course_id == $course->id ? 'selected' : ''); ?>><?php echo e($course->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="lesson_id"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                style="width: 200px;">
                <option value="">All Lessons</option>
                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($lesson->id); ?>" <?php echo e(request()->lesson_id == $lesson->id ? 'selected' : ''); ?>><?php echo e($lesson->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <input type="text" name="title" placeholder="Search by title..." value="<?php echo e(request()->title); ?>"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm"
                style="width: 300px;">

            <select name="status"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm">
                <option value="">All Status</option>
                <option value="active" <?php echo e(request()->status == 'active' ? 'selected' : ''); ?>>Active</option>
                <option value="trashed" <?php echo e(request()->status == 'trashed' ? 'selected' : ''); ?>>Trashed</option>
            </select>

            <button type="submit"
                class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 text-sm">
                <i class="fas fa-filter"></i> Apply Filters
            </button>

            <a href="<?php echo e(route('quizzes.index')); ?>"
                class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                <i class="fas fa-undo"></i>
            </a>
        </div>
    </form>

    <!-- Quizzes Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Title</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Course</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Lesson</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Status</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-colors duration-200">
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($quiz->id); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($quiz->title); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($quiz->course->title ?? 'N/A'); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($quiz->lesson->title ?? 'N/A'); ?></td>
                    <td class="px-6 py-4 text-sm text-center text-gray-800"><?php echo e($quiz->deleted_at ? 'Trashed' : 'Active'); ?></td>
                    <td class="px-6 py-4 text-sm text-center">
                        <div class="flex justify-center space-x-3">
                            <a href="<?php echo e(route('quizzes.show', $quiz->id)); ?>"
                                class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm">
                                View
                            </a>
                            <a href="<?php echo e(route('quizzes.edit', $quiz->id)); ?>"
                                class="bg-yellow-500 text-white px-4 py-2 rounded-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-sm">
                                Edit
                            </a>
                            <?php if($quiz->deleted_at): ?>
                            <form action="<?php echo e(route('quizzes.restore', $quiz->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <button type="submit"
                                    class="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-400 text-sm">
                                    Restore
                                </button>
                            </form>
                            <form action="<?php echo e(route('quizzes.permanentDelete', $quiz->id)); ?>" method="POST"
                                class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 text-sm">
                                    Delete Permanently
                                </button>
                            </form>
                            <?php else: ?>
                            <form action="<?php echo e(route('quizzes.delete', $quiz->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 text-sm">
                                    Delete
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        <?php echo e($quizzes->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/quizzes/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Add Quiz Result</h1>
    <form action="<?php echo e(route('quiz_results.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="quiz_id">Select Quiz</label>
            <select name="quiz_id" id="quiz_id" class="form-control" required>
                <option value="" disabled selected>Select a quiz</option>
                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($quiz->id); ?>"><?php echo e($quiz->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="user_id">Select User</label>
            <select name="user_id" id="user_id" class="form-control" required>
                <option value="" disabled selected>Select a user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="score">Score</label>
            <input type="number" name="score" id="score" class="form-control" min="0" max="100" required>
        </div>

        <div class="form-group">
            <label for="completed">Completed</label>
            <select name="completed" id="completed" class="form-control" required>
                <option value="" disabled selected>Select status</option>
                <option value="1">Yes</option>
                <option value="0">No</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/quiz_results/create.blade.php ENDPATH**/ ?>
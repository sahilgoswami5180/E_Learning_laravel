<?php $__env->startSection('content'); ?>

<!-- Success and Error Toasts -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>

<script>
    setTimeout(() => {
         document.querySelector('#successToast').style.display = 'none';
     }, 4000);
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>

<script>
    setTimeout(() => {
         document.querySelector('#errorToast').style.display = 'none';
     }, 4000);
</script>
<?php endif; ?>

<div class="container mx-auto top-0">
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('instructor.dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('lessons.index')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Lessons</a>
                </div>
            </li>
        </ol>
    </div>

    <!-- Filter Bar -->
    <div class="mb-4 p-4 bg-gray-50 rounded-lg shadow-md">
        <form action="<?php echo e(route('lessons.index')); ?>" method="GET" class="flex space-x-4">


            <!-- Filter by Lesson Title -->
            <div>
                <label for="lesson_title" class="block text-sm font-medium text-gray-600">Lesson Title</label>
                <input type="text" id="lesson_title" name="lesson_title" value="<?php echo e(request()->get('lesson_title')); ?>"
                    class="mt-1 p-2 border border-gray-300 rounded-md w-full max-w-xs"
                    placeholder="Search by lesson...">
            </div>
            <!-- Filter by Course Title -->
            <div>
                <label for="course_title" class="block text-sm font-medium text-gray-600">Course</label>
                <input type="text" id="course_title" name="course_title" value="<?php echo e(request()->get('course_title')); ?>"
                    class="mt-1 p-2 border border-gray-300 rounded-md w-full max-w-xs"
                    placeholder="Search by course...">
            </div>

            <!-- Filter by Status -->
            <div>
                <label for="status" class="block text-sm font-medium text-gray-600">Status</label>
                <select name="status" id="status" class="mt-1 p-2 border border-gray-300 rounded-md w-full max-w-xs">
                    <option value="">All</option>
                    <option value="active" <?php echo e(request()->get('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="trashed" <?php echo e(request()->get('status') == 'trashed' ? 'selected' : ''); ?>>Trashed
                    </option>
                </select>
            </div>

            <!-- Submit Button -->
            <div class="flex items-end">
                <button type="submit"
                    class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition duration-300 text-sm">
                    Filter
                </button>
                <a href="<?php echo e(route('lessons.index')); ?>"
                    class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                    <i class="fas fa-undo"></i>
                </a>
            </div>
        </form>
    </div>

    <!-- Action Buttons: Add New Lesson, Active and Trashed Lessons -->
    <div class="flex justify-end mb-4">
        <a href="<?php echo e(route('lessons.create')); ?>"
            class="bg-indigo-600 text-white px-4 py-2 rounded-full shadow-md hover:bg-indigo-700 transition duration-300 text-sm">
            Add New Lesson
        </a>
        <a href="<?php echo e(route('lessons.index', ['trashed' => false])); ?>"
            class="ml-4 bg-gray-500 text-white px-4 py-2 rounded-full shadow-md hover:bg-gray-600 transition duration-300 text-sm">
            Active Lessons
        </a>
        <a href="<?php echo e(route('lessons.index', ['trashed' => true])); ?>"
            class="ml-4 bg-yellow-500 text-white px-4 py-2 rounded-full shadow-md hover:bg-yellow-600 transition duration-300 text-sm">
            Trashed Lessons
        </a>
    </div>

    <!-- Lessons Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Title</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Course</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($loop->iteration); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($lesson->title); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($lesson->course->title ?? 'Unassigned'); ?></td>
                    <td class="px-6 py-4 text-sm text-center">
                        <div class="flex justify-center space-x-4">
                            <a href="<?php echo e(route('lessons.show', $lesson->id)); ?>"
                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                <i class="fas fa-eye"></i>
                            </a>
                            <?php if($lesson->deleted_at): ?>
                            <form action="<?php echo e(route('lessons.restore', $lesson->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 text-sm">
                                    Restore
                                </button>
                            </form>
                            <form action="<?php echo e(route('lessons.forceDelete', $lesson->id)); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm">
                                    Permanently Delete
                                </button>
                            </form>
                            <?php else: ?>
                            <a href="<?php echo e(route('lessons.edit', $lesson->id)); ?>"
                                class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition duration-300 text-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('lessons.destroy', $lesson->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm"
                                    onclick="return confirm('Are you sure you want to delete this lesson?');">
                                    Delete
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <div class="mt-4 text-sm">
        <?php echo e($lessons->links()); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/lesson/index.blade.php ENDPATH**/ ?>
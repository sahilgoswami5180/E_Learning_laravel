<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Course</h1>
    <form action="<?php echo e(route('course.update', $course->id)); ?>" method="POST">
        <!-- Pass the course ID here -->
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Course Title</label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo e($course->title); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control" required><?php echo e($course->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="duration">Duration (in hours)</label>
            <input type="number" name="duration" id="duration" class="form-control" value="<?php echo e($course->duration); ?>"
                required>
        </div>
        <div class="form-group">
            <label for="price">Price (in USD)</label>
            <input type="number" name="price" id="price" class="form-control" value="<?php echo e($course->price); ?>" step="0.01"
                required>
        </div>
        <div class="form-group">
            <label for="instructor_id">Assign Instructor</label>
            <select name="instructor_id" id="instructor_id" class="form-control">
                <option value="">None</option>
                <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($instructor->id); ?>" <?php if($instructor->id == $course->instructor_id): ?> selected <?php endif; ?>>
                    <?php echo e($instructor->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success mt-3">Update Course</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/course/edit.blade.php ENDPATH**/ ?>
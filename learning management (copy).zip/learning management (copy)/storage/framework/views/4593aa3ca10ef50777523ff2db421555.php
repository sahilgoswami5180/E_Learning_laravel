<?php $__env->startSection('title', 'E-commerce Shopping | Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header Section -->
<section id="page-header" class="about-header" style="background-image: url('./img/about/banner.png');">
    <h2>#let's_talk</h2>
    <p>LEAVE A MESSAGE, We love to hear from you!</p>
</section>

<!-- Cart Section -->
<section id="cart" class="section-p1">
    <?php if($cartItems->isEmpty()): ?>
    <!-- Empty Cart Section -->
    <div
        class="max-w-full min-h-[400px] mx-auto bg-gradient-to-r from-blue-100 to-blue-200 shadow-xl rounded-xl p-8 flex flex-col items-center justify-center text-center">
        <i class="fas fa-shopping-cart text-7xl text-gray-600 mb-6 animate-pulse"></i>
        <h2 class="text-2xl sm:text-3xl md:text-xl font-bold text-gray-800 mb-4">Your Cart is Empty</h2>
        <p class="text-gray-600 text-lg mb-6">It appears that you have not added any products to your cart yet. Browse
            our collection and find something that suits your needs.</p>
        <div class="mt-6">
            <a href="<?php echo e(route('shop.index')); ?>"
                class="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
                <i class="fas fa-arrow-left"></i>
                <span>Browse Our Products</span>
            </a>
        </div>
    </div>
    <?php else: ?>
    <!-- Cart Items Layout -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4 w-full">
        <!-- Parent container for multiple item cards -->
        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="cart-item-<?php echo e($item->id); ?>"
            class="flex flex-col sm:flex-row items-center space-x-2 bg-white shadow-lg w-full rounded-xl p-4">

            <!-- Remove Button -->
            <form action="<?php echo e(route('cart.remove', $item)); ?>" method="POST" class="flex-shrink-0 relative group">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <!-- Remove Button with Tooltip -->
                <button type="submit"
                    class="text-red-400 bg-white border-red-600 px-0 py-0 sm:px-4 sm:py-2 rounded-md hover:text-white hover:bg-red-400 focus:outline-none absolute top-2 -left-40 text-xl sm:text-2xl sm:static sm:border-2 sm:border-red-600 sm:top-auto sm:right-auto lg:border-2 lg:border-red-600">
                    <i class="fas fa-times-circle"></i>
                </button>

                <!-- Tooltip -->
                <span
                    class="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block bg-red-800 text-red-100 text-xs font-medium py-1 px-2 rounded-md shadow-lg transition-opacity duration-300 opacity-0 group-hover:opacity-100">
                    Remove
                </span>
            </form>

            <!-- Product Image -->
            <div class="w-16 h-16 sm:w-20 sm:h-20 md:w-28 md:h-28 lg:w-24 lg:h-20 flex-shrink-0">
                <?php
                $images = explode(',', $item->product->images);
                ?>
                <img src="<?php echo e(asset('storage/' . trim($images[0]))); ?>" alt="<?php echo e($item->product->name); ?> - Image"
                    class="w-full h-full object-cover rounded-lg">
            </div>

            <!-- Product Content -->
            <div class="flex-grow">
                <h3 class="text-lg sm:text-xl md:text-lg lg:text-xl font-semibold text-gray-800 break-words">
                    <?php echo e(Str::limit($item->product->name, 30, '...')); ?>

                </h3>
                <p class="text-gray-600 mb-4">₹<?php echo e(number_format($item->product->price, 2)); ?></p>

                <!-- Quantity Controls -->
                <form action="<?php echo e(route('cart.updateQuantity', $item)); ?>" method="POST" class="flex items-center">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <!-- Decrease Quantity -->
                    <button type="submit" name="quantity" value="<?php echo e($item->quantity - 1); ?>"
                        class="w-8 h-8 bg-red-500 text-white font-semibold rounded-l-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50 <?php echo e($item->quantity <= 1 ? 'bg-gray-400 cursor-not-allowed opacity-50' : ''); ?>">
                        <i class='bx bxs-minus-circle'></i>
                    </button>

                    <!-- Quantity Display -->
                    <span class="w-16 text-center py-1 border-t border-b rounded-md bg-gray-100 inline-block">
                        <?php echo e($item->quantity); ?>

                    </span>

                    <!-- Increase Quantity -->
                    <button type="submit" name="quantity" value="<?php echo e($item->quantity + 1); ?>"
                        class="w-8 h-8 bg-green-500 text-white font-semibold rounded-r-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50">
                        <i class='bx bxs-plus-circle'></i>
                    </button>
                </form>

                <!-- Subtotal -->
                <p class="text-gray-800 mt-4 font-semibold">Subtotal: ₹<?php echo e(number_format($item->product->price *
                    $item->quantity, 2)); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</section>



<!-- Cart Add Section: Coupon & Total -->
<section id="cart-add" class="section-p1">
    <div id="coupon" class="p-6 bg-gray-100">
        <span class="text-gray-500">Upcoming...</span>
        <h3 class="text-xl font-semibold mt-4 mb-4">Apply Coupon</h3>
        <div class="flex items-center space-x-2 mb-10">
            <input type="text" placeholder="Enter Your Coupon"
                class="border p-2 rounded-lg w-2/3 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <button id="applyCouponBtn"
                class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                disabled>
                Apply
            </button>
        </div>
    </div>


    <div id="subtotal">
        <h3>Cart Total</h3>
        <?php
        $subtotal = $cartItems->sum(fn($item) => $item->product->price * $item->quantity);
        $shippingFee = $subtotal >= 300 ? 0 : 25; // Free shipping if total is ₹300 or more, else ₹25
        $total = $subtotal + $shippingFee;
        ?>
        <table>
            <tr>
                <td>Cart Subtotal</td>
                <td>₹<?php echo e(number_format($subtotal, 2)); ?></td>
            </tr>
            <tr>
                <td>Shipping</td>
                <td>
                    <?php if($shippingFee == 0): ?>
                    Free
                    <?php else: ?>
                    ₹25
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td><strong>Total</strong></td>
                <td><strong>₹<?php echo e(number_format($total, 2)); ?></strong></td>
            </tr>
        </table>

        <a href="<?php echo e(route('user.checkout')); ?>"
            class="normal py-1 px-2 sm:px-4 sm:py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-all"><i
                class="fa-solid fa-money-check"></i>
            Proceed to Checkout</a>
    </div>
    <script>
        const inputField = document.querySelector('input[type="text"]');
const applyButton = document.querySelector('#applyCouponBtn');

inputField.addEventListener('input', () => {
    if (inputField.value.trim() !== '') {
        applyButton.disabled = false;
    } else {
        applyButton.disabled = true;
    }
});

    </script>

</section>

<!-- Toast Notifications -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>
<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>
<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (another copy)/resources/views/user/cart.blade.php ENDPATH**/ ?>
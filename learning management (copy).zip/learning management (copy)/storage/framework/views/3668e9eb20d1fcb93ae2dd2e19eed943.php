<?php $__env->startSection('content'); ?>
    <div class="container mx-auto my-8 px-4">
        <h2 class="text-3xl font-semibold text-gray-900 mb-8">My Orders</h2>

        <?php if($orders->isEmpty()): ?>
            <div class="text-center text-gray-600">
                <p class="text-lg mb-4">You haven't placed any orders yet. Start shopping now!</p>
                <a href="<?php echo e(route('user.index')); ?>"
                    class="inline-block px-8 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition duration-300 ease-in-out shadow-lg transform hover:scale-105">Shop
                    Now</a>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto bg-white shadow-lg rounded-lg border border-gray-200">
                <table class="min-w-full text-sm text-gray-700">
                    <thead class="bg-blue-50 border-b">
                        <tr>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Order Date</th>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Total Amount</th>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Status</th>
                            <th class="py-4 px-6 text-left font-semibold text-blue-700 tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b hover:bg-gray-50 transition duration-300 ease-in-out hover:shadow-lg">
                                <td class="py-3 px-6 text-gray-800"><?php echo e($order->created_at->format('M j, Y')); ?></td>
                                <td class="py-3 px-6 font-semibold text-gray-900">$<?php echo e(number_format($order->total, 2)); ?>

                                </td>
                                <td class="py-3 px-6">
                                    <span
                                        class="px-3 py-1 rounded-full text-sm
        <?php echo e($order->status == 'pending'
            ? ' text-yellow-600'
            : ($order->status == 'paid'
                ? ' text-green-700'
                : ($order->status == 'cash on delivery'
                    ? ' text-blue-600'
                    : 'bg-red-200 text-red-700'))); ?>

        font-medium">
                                        <?php echo e(ucfirst($order->status)); ?>

                                    </span>
                                </td>

                                <td class="py-3 px-6">
                                    <a href="<?php echo e(route('user.myorder-details', $order->id)); ?>"
                                        class="text-blue-600 hover:text-blue-800 font-medium hover:underline transition duration-300 ease-in-out">
                                        View Details
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/user/orders.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Checkout - ' . $course->title); ?>

<?php $__env->startSection('content'); ?>

<!-- Success Toast -->
<?php if(session('success')): ?>
<div id="successToast" class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>
<?php endif; ?>

<!-- Error Toast -->
<?php if(session('error')): ?>
<div id="errorToast" class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>
<?php endif; ?>

<div class="container mx-auto mt-10 px-6">
    <!-- Course Title -->
    <h1 class="text-4xl font-semibold text-gray-800 mb-6 text-center"><?php echo e($course->title); ?></h1>
    
    <!-- Checkout Overview -->
    <div class="bg-white shadow-lg rounded-lg p-8 mb-8">
        <p class="text-gray-600 text-lg mb-4">Total Amount: <strong>₹<?php echo e($finalTotal); ?></strong></p>
        <p class="text-gray-600 text-lg mb-4">Course: <strong><?php echo e($course->title); ?></strong></p>
        <p class="text-gray-600 text-lg mb-6">Instructor: <strong><?php echo e($course->instructor->name ?? 'Not Assigned'); ?></strong></p>
        
        <div class="flex justify-between items-center mb-4">
            <span class="text-gray-600 text-lg">Proceed with payment</span>
            <i class="fas fa-credit-card text-blue-500 text-2xl"></i>
        </div>
    </div>

    <!-- Payment Selection Section -->
    <div class="bg-white shadow-lg rounded-lg p-8 mb-8">
        <h2 class="text-3xl font-semibold text-gray-800 mb-6">Complete Your Purchase</h2>
        <p class="text-lg text-gray-600 mb-6">Total Amount: ₹<?php echo e($finalTotal); ?></p>

        <p class="text-lg text-gray-600 mb-6">To confirm and proceed with the payment, select one of the options below:</p>

        <!-- Payment Method Selection Form -->
        <form action="<?php echo e(route('razorpay.checkout', ['courseId' => $course->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
            <input type="hidden" name="total_amount" value="<?php echo e($finalTotal); ?>">
            
            <!-- Razorpay Option -->
            <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all">
                <i class="fas fa-credit-card text-4xl text-blue-500"></i>
                <h4 class="mt-2 font-medium text-lg">Pay with Razorpay</h4>
                <p class="text-gray-600 mt-2">Pay securely via Razorpay</p>
                <button id="razorpay-button" class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300 mt-4">
                    <i class="fas fa-credit-card"></i> Pay with Razorpay
                </button>
            </div>
        </form>
    </div>

    <!-- Confirmation Section -->
    <div class="bg-white shadow-lg rounded-lg p-8 mb-8 text-center">
        <h3 class="text-xl font-semibold text-gray-800 mb-4">Transaction Confirmation</h3>
        <p class="text-lg text-gray-600 mb-6">By proceeding, you confirm that you are purchasing the course and agree to the terms and conditions.</p>
        
        <!-- Check Icons for Confirmation -->
        <div class="flex justify-center mb-6">
            <i class="fas fa-check-circle text-green-500 text-3xl mr-4"></i>
            <i class="fas fa-lock text-gray-600 text-3xl"></i>
        </div>
        
        <p class="text-gray-600 text-sm mb-6">Your information is secure with us. For any queries, contact support.</p>
    </div>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    document.getElementById('razorpay-button').onclick = function(e) {
        e.preventDefault();

        var options = {
            key: "<?php echo e(env('RAZORPAY_KEY')); ?>", // Razorpay Key
            amount: "<?php echo e($finalTotal * 100); ?>", // Amount in paise
            name: "Course Purchase",
            description: "Course: <?php echo e($course->title); ?>",
            image: "<?php echo e(asset('images/logo.png')); ?>",
            order_id: "<?php echo e($razorpayOrder['id']); ?>", // Order ID created by server
            handler: function (response) {
                // On successful payment, redirect to the success page
                window.location.href = "<?php echo e(route('payment.success')); ?>?razorpay_order_id=" + response.razorpay_order_id + "&razorpay_payment_id=" + response.razorpay_payment_id + "&razorpay_signature=" + response.razorpay_signature;
            },
            theme: {
                color: "#3399cc"
            }
        };

        var rzp = new Razorpay(options);
        rzp.open();
    };
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/student/razorpay_checkout.blade.php ENDPATH**/ ?>
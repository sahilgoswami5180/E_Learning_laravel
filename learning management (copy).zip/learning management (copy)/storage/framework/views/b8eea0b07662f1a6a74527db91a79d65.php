<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce Shopping | Login Page</title>

    <!-- Include Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Link to your custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* Apply Poppins font to the entire body */
        body {
            font-family: 'Poppins', sans-serif;
        }

        /* Optional: Apply Poppins to headers and labels */
        h2,
        label {
            font-family: 'Poppins', sans-serif;
        }

        /* Apply custom border-radius to inputs and buttons for a smoother look */
        input,
        button {
            border-radius: 30px;
            /* Increased border-radius for a smoother rounded look */
        }

        /* Ensure the Sign In and Sign Up links are always side by side */
        .card__header {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            /* Space between links */
            margin-bottom: 16px;
            margin-top: -5px;
        }

        .card__header span,
        .card__header a {
            /* font-weight: bold; */
            text-align: center;
            padding: 5px;
            cursor: pointer;
            text-decoration: none;
            color: #4e73df;
            /* Default blue color */
            border-bottom: 3px solid transparent;
            transition: color 0.3s ease-in-out, border-color 0.3s ease-in-out;
            font-size: 16px;
            /* Slightly larger font size */
        }

        /* For Sign up link - Grey out initially */
        .card__header .card__signup {
            color: #858796;
            /* Slightly greyed out */
        }

        /* For Sign in link - Highlight it initially */
        .card__header .card__signin {
            color: #4e73df;
            border-bottom-color: #4e73df;
            /* Bottom border to indicate active state */
        }

        /* Hover effect for Sign up link */
        .card__header .card__signin:hover {
            color: #3b8bff;
            /* Hover effect to slightly darken blue */
            border-bottom-color: #3b8bff;
            /* Change the bottom border color on hover */
        }

        /* Hover effect for Sign in link */
        .card__header .card__signup:hover {
            color: #3b8bff;
            /* Hover effect to darken grey */
            border-bottom-color: #3b8bff;
        }

        /* When Sign up link is active */
        .card__header .card__signup.active {
            color: #4e73df;
            border-bottom-color: #4e73df;
            /* Active bottom border color */
        }

        /* When Sign in link is active */
        .card__header .card__signin.active {
            color: #4e73df;
            border-bottom-color: #4e73df;
            /* Active bottom border color */
        }

        /* Default styling for the main container */
        .main-container {
            max-width: 1000px;
            margin: auto;
            padding: 0px;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            margin-top: 25px;
            /* margin-bottom: 20px; */
        }

        .flex-layout {
            display: flex;
            justify-content: space-between;
            flex-direction: row;
            width: 100%;
        }

        /* Image and Form layout for large screens */
        .image-container {
            display: block;
            width: 50%;
            padding-right: 1rem;
        }

        .form-container {
            width: 50%;
            padding-left: 1rem;
            /* Add a shadow only on the left side */

        }

        /* Ensure no left margin for input fields */
        input {
            margin-left: 0 !important;
            /* Ensures no margin-left is applied */
        }

        /* Optional: Reset any margin from children of form-container */
        .form-container>* {
            margin-left: 0 !important;
            /* Remove any left margin from children like inputs */
        }

        /* Media Queries for Responsiveness */
        @media screen and (max-width: 1024px) {
            .flex-layout {
                flex-direction: column;
                align-items: center;
            }

            .image-container,
            .form-container {
                width: 100%;
                padding-right: 0;
                padding-left: 0;
            }

            .main-container {
                padding: 1rem;
            }
        }

        @media screen and (max-width: 768px) {
            .card__header {
                gap: 1rem;
                /* Reduce gap between the links on smaller screens */
            }

            .card__header span,
            .card__header a {
                font-size: 1rem;
            }

            .form-container {
                width: 100%;
            }

            .image-container {
                display: none;
            }
        }

        @media screen and (max-width: 480px) {
            .main-container {
                padding: 0.5rem;
            }

            .card__header span,
            .card__header a {
                font-size: 0.9rem;
            }
        }
    </style>

</head>

<body class="bg-gray-100">
    <!-- Success Toast -->
    <?php if(session('success')): ?>
    <div id="successToast"
        class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-2 rounded-md shadow-md flex items-center space-x-3">
        <!-- Success Icon -->
        <i class="fas fa-check-circle text-white text-2xl"></i>
        <!-- Success Message -->
        <span><?php echo e(session('success')); ?></span>
    </div>

    <script>
        setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
    </script>
    <?php endif; ?>

    <!-- Error Toast -->
    <?php if(session('error')): ?>
    <div id="errorToast"
        class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-2 rounded-md shadow-md flex items-center space-x-3">
        <!-- Error Icon -->
        <i class="fas fa-times-circle text-white text-2xl"></i>
        <!-- Error Message -->
        <span><?php echo e(session('error')); ?></span>
    </div>

    <script>
        setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
    </script>
    <?php endif; ?>

    <!-- Main Container for Login Form -->
    <div class="main-container">
        <div class="card__header w-full text-center py-4">
            <a href="<?php echo e(route('register')); ?>"
                class="card__signup text-blue-500 hover:text-blue-700 font-semibold cursor-pointer">Sign up</a>
            <span class="card__signin text-blue-500 hover:text-blue-700 font-semibold cursor-pointer">Sign in</span>
        </div>

        <!-- Flex layout for Image and Form -->
        <div class="flex-layout">
            <!-- Left side (Image) -->
            <div class="image-container">
                <img src="https://img.freepik.com/free-vector/tablet-login-concept-illustration_114360-7963.jpg?t=st=1734600581~exp=1734604181~hmac=bb01b7e8e4c9810ac76c4b66d078f4ed75b32851f8acad500f966179919b228f&w=740"
                    alt="Login Image" class="w-full h-full object-cover rounded-lg" style="margin-bottom:18px;">
            </div>

            <!-- Right side (Form) -->
            <div class="form-container bg-white p-8 mx-4 w-full md:w-1/2" style="margin-top:-30px;">
                <h2 class="text-2xl font-bold text-center mb-2">Login to Your Account</h2>
                <p class="text-center text-gray-600 mb-4">Enter your credentials to continue</p>
                <form id="login-form" action="<?php echo e(route('login')); ?>" method="POST" class="space-y-4">
                    <?php echo csrf_field(); ?>

                    <!-- Email Field -->
                    <div class="relative">
                        <label for="email" class="block text-gray-700 font-medium mb-2">Email <span
                                class="text-red-600">*</span></label>
                        <input type="email" name="email" id="email"
                            class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Email" value="<?php echo e(old('email')); ?>">
                        <span id="email-icon" class="absolute right-3 text-gray-500" style="top: 40px;">
                            <i class="fas fa-envelope"></i>
                        </span>
                        <span id="email-validation-icon" class="absolute text-gray-500" style="top:40px; right:-25px;">
                            <i id="email-validation-status" class="fas fa-times-circle"
                                title="Enter a valid email address (e.g., user@example.com)"></i>
                            <!-- Tooltip message for email -->
                        </span>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Password Field -->
                    <div class="relative">
                        <label for="password" class="block text-gray-700 font-medium mb-2">Password <span
                                class="text-red-600">*</span></label>
                        <input type="password" name="password" id="password"
                            class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Password">
                        <span id="toggle-password" class="absolute right-3 cursor-pointer text-gray-500"
                            style="top: 40px;" onclick="togglePassword()">
                            <i id="password-icon" class="fas fa-eye"></i>
                        </span>
                        <span id="password-validation-icon" class="absolute text-gray-500"
                            style="top:40px; right:-25px;">
                            <i id="password-validation-status" class="fas fa-times-circle"
                                title="Password must be between 8-13 characters, contain an uppercase letter, a number, and a special character."></i>
                            <!-- Tooltip message for password -->
                        </span>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    <!-- Remember me checkbox -->
                    <div class="flex items-center justify-between flex-wrap">
                        <!-- Allow wrapping -->
                        <div class="mr-4">
                            <!-- Optional margin for spacing -->
                            <label for="remember" class="flex items-center">
                                <input type="checkbox" name="remember" id="remember"
                                    class="h-4 w-4 text-blue-500 border-gray-300 rounded focus:ring-2 focus:ring-blue-500">
                                <span class="ml-2 text-gray-700">Remember me</span>
                            </label>
                        </div>

                        <!-- The 'Forgot Password?' link is pushed to the next line and aligned at the end -->
                        <div class="w-full mt-2 flex justify-end">
                            <!-- Use w-full for full width and justify-end to align to the right -->
                            <a href="<?php echo e(route('forgot.password')); ?>" class="text-blue-500 hover:underline">Forgot
                                Password?</a>
                        </div>
                    </div>



                    <button type="submit"
                        class="flex justify-center m-auto w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition">Login</button>
                </form>


            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            const emailIcon = document.getElementById('email-validation-status');
            const passwordIcon = document.getElementById('password-validation-status');
            const emailValidationIcon = document.getElementById('email-validation-icon');
            const passwordValidationIcon = document.getElementById('password-validation-icon');

            // Function to validate email
            const validateEmail = (emailValue) => {
                const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

                // Clear old color classes
                emailValidationIcon.classList.remove('text-red-500', 'text-green-500');
                emailValidationIcon.classList.add('text-gray-500'); // Reset color

                if (emailPattern.test(emailValue)) {
                    emailIcon.classList.remove('fa-times-circle');
                    emailIcon.classList.add('fa-check-circle');
                    emailValidationIcon.classList.remove('text-gray-500');
                    emailValidationIcon.classList.add('text-green-500'); // Apply green color
                } else {
                    emailIcon.classList.remove('fa-check-circle');
                    emailIcon.classList.add('fa-times-circle');
                    emailValidationIcon.classList.remove('text-gray-500');
                    emailValidationIcon.classList.add('text-red-500'); // Apply red color
                }
            };

            // Function to validate password
            const validatePassword = (passwordValue) => {
                const minLength = 8;
                const maxLength = 13;
                const hasUpperCase = /[A-Z]/.test(passwordValue);
                const hasNumber = /[0-9]/.test(passwordValue);
                const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(passwordValue);

                // Clear old color classes
                passwordValidationIcon.classList.remove('text-red-500', 'text-green-500');
                passwordValidationIcon.classList.add('text-gray-500'); // Reset color

                if (passwordValue.length >= minLength && passwordValue.length <= maxLength && hasUpperCase &&
                    hasNumber && hasSpecialChar) {
                    passwordIcon.classList.remove('fa-times-circle');
                    passwordIcon.classList.add('fa-check-circle');
                    passwordValidationIcon.classList.remove('text-gray-500');
                    passwordValidationIcon.classList.add('text-green-500'); // Apply green color
                } else {
                    passwordIcon.classList.remove('fa-check-circle');
                    passwordIcon.classList.add('fa-times-circle');
                    passwordValidationIcon.classList.remove('text-gray-500');
                    passwordValidationIcon.classList.add('text-red-500'); // Apply red color
                }
            };

            // Check if email and password are pre-filled and validate on page load
            if (emailInput.value) {
                validateEmail(emailInput.value);
            }

            if (passwordInput.value) {
                validatePassword(passwordInput.value);
            }

            // Add event listener for email input
            emailInput.addEventListener('input', () => {
                const emailValue = emailInput.value;
                validateEmail(emailValue);
            });

            // Add event listener for password input
            passwordInput.addEventListener('input', () => {
                const passwordValue = passwordInput.value;
                validatePassword(passwordValue);
            });
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const signupLink = document.querySelector('.card__signup');
            const signinLink = document.querySelector('.card__signin');

            signupLink.addEventListener('click', () => {
                signupLink.classList.add('active');
                signinLink.classList.remove('active');
            });

            signinLink.addEventListener('click', () => {
                signinLink.classList.add('active');
                signupLink.classList.remove('active');
            });
        });
    </script>
    <script>
        // Toggle password visibility
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const passwordIcon = document.getElementById('password-icon');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.classList.remove('fa-eye');
                passwordIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                passwordIcon.classList.remove('fa-eye-slash');
                passwordIcon.classList.add('fa-eye');
            }
        }

        // Check if cookies exist and user is in the database
        window.onload = function() {
            const cookies = document.cookie.split(';');
            let userDataCookie = '';

            cookies.forEach(cookie => {
                const [key, value] = cookie.trim().split('=');
                if (key === 'user_data') userDataCookie = decodeURIComponent(value);
            });

            if (userDataCookie) {
                const userData = JSON.parse(userDataCookie);

                // Optionally display last login time (e.g., in the form or as a separate message)
                const lastLoginDisplay = document.getElementById('last-login');
                if (lastLoginDisplay) {
                    lastLoginDisplay.textContent = `Last login: ${new Date(userData.last_login_at).toLocaleString()}`;
                }

                // Call your backend to check if user exists in the database
                fetch(`/check-user-existence?email=${userData.email}`, {
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json',
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (!data.exists) {
                            // If user doesn't exist, clear the cookies
                            document.cookie = 'user_data=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/';
                        } else {
                            // Populate form fields with the data from the cookie
                            document.getElementById('email').value = userData.email;
                            document.getElementById('password').value = userData.password;
                            document.getElementById('remember').checked = true;
                        }
                    })
                    .catch(error => {
                        console.error('Error checking user existence:', error);
                        // Clear cookies in case of error
                        document.cookie = 'user_data=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/';
                    });
            }
        };


        // Remember credentials functionality
        document.getElementById('login-form').addEventListener('submit', function(e) {
            if (document.getElementById('remember').checked) {
                const email = document.getElementById('email').value;
                const password = document.getElementById('password').value;
                const lastLoginTime = new Date().toISOString(); // Capture current date/time as ISO string

                const userData = {
                    email: email,
                    password: password,
                    last_login_at: lastLoginTime // Add last login time
                };

                // Store user data (including last login time) in a cookie with a 1-day expiration
                document.cookie =
                    `user_data=${encodeURIComponent(JSON.stringify(userData))};max-age=86400;path=/`; // 1 day expiration
            }
        });
    </script>
</body>

</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (another copy)/resources/views/auth/login.blade.php ENDPATH**/ ?>
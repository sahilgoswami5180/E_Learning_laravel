<?php $__env->startSection('title', 'E-commerce Shopping | Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>


<!-- Notification Button and Modal -->


<?php if(session('success')): ?>
<div id="toastSuccess"
    class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out text-center">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="toastError"
    class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>
<?php endif; ?>

<script>
    function showToast(toastId) {
            let toast = document.querySelector(toastId);
            if (toast) {
                setTimeout(() => {
                    toast.classList.remove('opacity-0', 'translate-y-[-20px]');
                    toast.classList.add('opacity-100', 'translate-y-0');
                }, 10);

                setTimeout(() => {
                    toast.classList.remove('opacity-100', 'translate-y-0');
                    toast.classList.add('opacity-0', 'translate-y-[-20px]');
                }, 4000);
            }
        }

        <?php if(session('success')): ?>
            showToast('#toastSuccess');
        <?php endif; ?>

        <?php if(session('error')): ?>
            showToast('#toastError');
        <?php endif; ?>
</script>

<!-- JavaScript for Toggle Effect -->
<script>
    function toggleNotificationPanel(event) {
            event.preventDefault();
            const panel = document.getElementById('notificationModal');

            // Toggle modal visibility and apply transition
            if (panel.classList.contains('hidden')) {
                panel.classList.remove('hidden');
                panel.classList.add('scale-100', 'transform', 'transition-transform', 'duration-200', 'ease-in-out');
            } else {
                panel.classList.add('hidden');
                panel.classList.remove('scale-100', 'transform', 'transition-transform', 'duration-200', 'ease-in-out');
            }
        }
</script>
<!-- Mark All as Read JS -->
<script>
    document.getElementById('markAllAsReadBtn').addEventListener('click', function() {
            if (confirm('Are you sure you want to mark all notifications as read?')) {
                // Send a request to mark all notifications as read
                fetch('<?php echo e(route('contact-msg.mark-all-as-read')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    },
                }).then(response => {
                    if (response.ok) {
                        location.reload(); // Reload the page to reflect the changes
                    }
                });
            }
        });

        // Clear All Notifications
        document.getElementById('clearAllBtn').addEventListener('click', function() {
            if (confirm('Are you sure you want to clear all notifications?')) {
                // Send a request to clear all notifications
                fetch('<?php echo e(route('contact-msg.clear-all')); ?>', {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                    },
                }).then(response => {
                    if (response.ok) {
                        location.reload(); // Reload the page to reflect the changes
                    }
                });
            }
        });
</script>

<?php $__env->startPush('scripts'); ?>
<script>
    window.onload = function() {
                setTimeout(() => {
                    document.getElementById('loader').style.display = 'none';
                }, 400);
            }
</script>
<?php $__env->stopPush(); ?>
<!-- Custom Scrollbar Styling -->
<style>
    /* Scrollbar styling */
    #notificationModal .overflow-y-auto {
        scrollbar-width: thin;
        scrollbar-color: #4B5563 #F3F4F6;
    }

    /* Webkit scrollbars for Chrome, Safari, and Edge */
    #notificationModal .overflow-y-auto::-webkit-scrollbar {
        width: 8px;
    }

    #notificationModal .overflow-y-auto::-webkit-scrollbar-thumb {
        background-color: #4B5563;
        border-radius: 10px;
    }

    #notificationModal .overflow-y-auto::-webkit-scrollbar-track {
        background: #F3F4F6;
        border-radius: 10px;
    }

    /* Button Styles */
    .btn-mark-read {
        @apply bg-blue-500 text-white font-semibold px-4 py-2 rounded-lg hover: bg-blue-600 focus:outline-none transition-all duration-200 ease-in-out;
    }

    .btn-mark-read i {
        @apply text-white;
    }

    /* Hover effects for List Items */
    li:hover {
        @apply bg-gray-50 cursor-pointer;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/instructor/dashboard.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Courses'); ?>

<?php $__env->startSection('content'); ?>

<!-- Toast Notifications -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>
<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>
<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>
<div class="container mx-auto mt-5 min-h-screen px-6">
    <!-- Page Header -->
    <div class="flex justify-between items-center text-center my-10">
        <h1 class="text-4xl font-bold text-gray-800 mb-4 border-b-4 border-blue-500 inline-block pb-2">Available Courses</h1>
    </div>

    <!-- Course Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white shadow-lg rounded-lg overflow-hidden transform transition duration-300 hover:scale-105 hover:shadow-xl">
            <div class="p-6">
                <!-- Course Title -->
                <h2 class="text-2xl font-semibold text-gray-800 mb-3"><?php echo e($course->title); ?></h2>

                <!-- Course Details -->
                <div class="mb-4 text-gray-700">
                    <p class="text-sm mb-2"><strong>Duration:</strong> <?php echo e($course->duration); ?> hours</p>
                    <p class="text-sm mb-2"><strong>Price:</strong> $<?php echo e(number_format($course->price, 2)); ?></p>
                    <p class="text-sm"><strong>Instructor:</strong> <?php echo e($course->instructor->name ?? 'Not Assigned'); ?></p>
                </div>

                <!-- Description -->
                <p class="text-sm text-gray-600 mb-6 line-clamp-3">
                    <?php echo e($course->description); ?>

                </p>

                <!-- Action Button (Conditional based on payment status) -->
                <?php
                    // Check if the user has paid for the course via CourseOrder model
                    $isPaid = \App\Models\CourseOrder::where('user_id', Auth::id())
                        ->where('course_id', $course->id)
                        ->where('status', 'completed') // Ensure the status is 'completed'
                        ->exists();
                ?>

                <?php if($isPaid): ?>
                    <!-- If the user has paid for the course, show "View Details" button -->
                    <a href="<?php echo e(route('course.show', $course->id)); ?>"
                        class="block text-center bg-blue-600 text-white px-6 py-3 rounded-lg shadow-md hover:bg-blue-700 hover:shadow-lg transition duration-300 transform hover:scale-105">
                        View Details
                    </a>
                <?php else: ?>
                    <!-- If the user has not paid for the course, show "Purchase" button -->
                    <a href="<?php echo e(route('razorpay.checkout', $course->id)); ?>"
                        class="block text-center bg-green-600 text-white px-6 py-3 rounded-lg shadow-md hover:bg-green-700 hover:shadow-lg transition duration-300 transform hover:scale-105">
                        Purchase Course
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Pagination (Optional) -->
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/student/index.blade.php ENDPATH**/ ?>
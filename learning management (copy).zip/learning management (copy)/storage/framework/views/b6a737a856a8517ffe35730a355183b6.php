<?php $__env->startSection('title', 'Quiz Result'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-5 px-4 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-semibold text-gray-800 mb-5">Quiz Result</h1>

    <div class="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 class="text-2xl font-semibold text-gray-700 mb-4"><?php echo e($quiz->title); ?></h2>
        <p class="text-gray-600">Course: <span class="font-semibold text-gray-800"><?php echo e($quiz->course->title); ?></span></p>

        <div class="mt-4">
            <p class="text-lg text-gray-700">Your Score: <span class="text-xl font-semibold text-green-600"><?php echo e($quizResult->score); ?> / <?php echo e($quizResult->total_questions); ?></span></p>

            <?php if($quizResult->score == $quizResult->total_questions): ?>
            <p class="text-green-600 mt-2">Excellent! You got a perfect score!</p>
            <?php elseif($quizResult->score >= $quizResult->total_questions * 0.7): ?>
            <p class="text-yellow-500 mt-2">Good job! You're on the right track.</p>
            <?php else: ?>
            <p class="text-red-600 mt-2">Don't worry! Keep practicing and you'll do better next time.</p>
            <?php endif; ?>
        </div>

        <!-- Optionally show detailed results -->
        <div class="mt-6">
            <h3 class="text-lg font-semibold text-gray-700">Detailed Results</h3>
            <ul class="list-none mt-3">
                <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="border-b border-gray-200 py-2">
                    <p class="text-gray-800"><?php echo e($loop->iteration); ?>. <?php echo e($question->question_text); ?></p>
                    <p class="text-gray-600">Your Answer: <?php echo e($question->user_answer ? $question->user_answer : 'Not
                        answered'); ?></p>
                    <p class="text-gray-600">Correct Answer: <?php echo e($question->correct_answer); ?></p>
                    <p
                        class="text-gray-600 <?php echo e($question->user_answer == $question->correct_answer ? 'text-green-500' : 'text-red-500'); ?>">
                        <?php echo e($question->user_answer == $question->correct_answer ? 'Correct' : 'Incorrect'); ?>

                    </p>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/student/quiz_result.blade.php ENDPATH**/ ?>
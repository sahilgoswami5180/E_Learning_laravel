<?php $__env->startSection('content'); ?>

<!-- Success and Error Toasts -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>

<script>
    setTimeout(() => {
         document.querySelector('#successToast').style.display = 'none';
     }, 4000);
</script>
<?php endif; ?>

<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>

<script>
    setTimeout(() => {
         document.querySelector('#errorToast').style.display = 'none';
     }, 4000);
</script>
<?php endif; ?>

<div class="container mx-auto top-0">
    <!-- Breadcrumb -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('instructor.dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>
            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('questions.index')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Questions</a>
                </div>
            </li>
        </ol>
    </div>

    <!-- Filter Bar and Action Buttons: Add New Question, Active and Trashed Questions -->
    <div class="flex justify-between my-4">
        <!-- Filter Form -->
        <form method="GET" action="<?php echo e(route('questions.index')); ?>" class="flex space-x-4">
            <!-- Filter by Quiz -->
            <select name="quiz_id"
                class="form-select px-4 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-400">
                <option value="">Select Quiz</option>
                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($quiz->id); ?>" <?php echo e(request('quiz_id')==$quiz->id ? 'selected' : ''); ?>><?php echo e($quiz->title); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <!-- Filter by Question Text -->
            <input type="text" name="question_text" value="<?php echo e(request('question_text')); ?>"
                placeholder="Search Question Text"
                class="form-input px-4 py-2 rounded-md border border-gray-300 focus:ring-2 focus:ring-blue-400">

            <!-- Submit Button -->
            <button type="submit"
                class="bg-indigo-600 text-white px-4 py-2 rounded-full shadow-md hover:bg-indigo-700 transition duration-300">Filter</button>
            <a href="<?php echo e(route('questions.index')); ?>"
                class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                <i class="fas fa-undo"></i>
            </a>
        </form>

        <!-- Action Buttons: Add New Question, Active and Trashed Questions -->
        <div class="flex space-x-2">
            <a href="<?php echo e(route('questions.create')); ?>"
                class="bg-indigo-600 text-white px-4 py-2 rounded-full shadow-md hover:bg-indigo-700 transition duration-300 text-sm">
                Add New Question
            </a>

            <a href="<?php echo e(route('questions.index', ['trashed' => true])); ?>"
                class="bg-yellow-500 text-white px-4 py-2 rounded-full shadow-md hover:bg-yellow-600 transition duration-300 text-sm">
                Trashed Questions
            </a>
        </div>
    </div>

    <!-- Questions Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Question</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Quiz</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Correct Answer</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Status</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($loop->iteration); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($question->question_text); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($question->quiz->title ?? 'Unassigned'); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($question->correct_answer); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800">
                        <?php echo e($question->deleted_at ? 'Trashed' : 'Active'); ?>

                    </td>
                    <td class="px-6 py-4 text-sm text-center">
                        <div class="flex justify-center space-x-4">
                            <a href="<?php echo e(route('questions.show', $question->id)); ?>"
                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 text-sm">
                                <i class="fas fa-eye"></i>
                            </a>
                            <?php if($question->deleted_at): ?>
                            <form action="<?php echo e(route('questions.restore', $question->id)); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 text-sm">
                                    Restore
                                </button>
                            </form>
                            <form action="<?php echo e(route('questions.forceDelete', $question->id)); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm">
                                    Permanently Delete
                                </button>
                            </form>
                            <?php else: ?>
                            <a href="<?php echo e(route('questions.edit', $question->id)); ?>"
                                class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 transition duration-300 text-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('questions.destroy', $question->id)); ?>" method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm"
                                    onclick="return confirm('Are you sure you want to delete this question?');">
                                    Delete
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <div class="mt-4 text-sm">
        <?php echo e($questions->appends(request()->query())->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/learning management/resources/views/questions/index.blade.php ENDPATH**/ ?>